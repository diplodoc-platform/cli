export declare function readPilotProof(): {
    transformSourceSha: string;
    transformVersion: string;
    transformRuntimeSha256: string;
    yamlVersion: string;
    yamlSmokePassed: boolean;
};
