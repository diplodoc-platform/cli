import type Token from 'markdown-it/lib/token';
import type { Heading } from './typings';
declare const _default: (tokens: Token[], needFlatListHeadings?: boolean, href?: string) => Heading[];
export = _default;
