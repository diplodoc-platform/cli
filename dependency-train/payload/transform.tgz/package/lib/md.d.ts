import type { OptionsType } from './typings';
import type Token from 'markdown-it/lib/token';
declare function initMarkdownIt(options: OptionsType): {
    parse: (input: string) => Token[];
    compile: (tokens: Token[]) => string;
    env: {
        title?: string;
        headings: import("./typings").Heading[];
        assets?: unknown[];
        meta?: object;
        changelogs?: import("./plugins/changelog/types").ChangelogItem[];
        additionalOptionsCssWhiteList?: import("./typings").CssWhiteList;
    };
};
export = initMarkdownIt;
