import type { MarkdownItPluginCb } from './plugins/typings';
declare const defaultPlugins: MarkdownItPluginCb[];
export = defaultPlugins;
