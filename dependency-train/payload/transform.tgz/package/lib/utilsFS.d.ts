import type { Dictionary } from 'lodash';
import type { StateCore } from './typings';
export declare function isFileExists(file: string): boolean;
export declare function resolveRelativePath(fromPath: string, relativePath: string): string;
export type GetFileTokensOpts = {
    getVarsPerFile?: (path: string) => Record<string, string>;
    vars?: Record<string, unknown>;
    disableLiquid?: boolean;
    disableLint?: boolean;
    lintMarkdown?: (opts: {
        input: string;
        path: string;
        sourceMap?: Dictionary<string>;
    }) => void;
    disableTitleRefSubstitution?: boolean;
    disableCircularError?: boolean;
    inheritVars?: boolean;
    conditionsInCode?: boolean;
    content?: string;
    root?: string;
};
export declare function getFileTokens(path: string, state: StateCore, options: GetFileTokensOpts, content?: string): import("markdown-it/lib/token")[];
export declare const getFullIncludePath: (includePath: string, root: string, path: string) => string;
export declare function getSinglePageAnchorId(args: {
    root: string;
    currentPath: string;
    pathname?: string;
    hash?: string | null;
}): string;
export declare function getPublicPath({ path, root, rootPublicPath, transformLink, }: {
    path?: string;
    root?: string;
    rootPublicPath?: string;
    transformLink?: (href: string) => string;
}, input?: string | null): string;
export declare function getRelativePath(path: string, toPath: string): string;
export declare function getRealPath(symlinkPath: string): string;
