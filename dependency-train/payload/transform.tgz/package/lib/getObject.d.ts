declare const _default: (path: string, obj: Record<string, any>, fallback?: any) => any;
export = _default;
