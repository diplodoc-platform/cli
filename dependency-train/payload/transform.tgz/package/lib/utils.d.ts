import type Token from 'markdown-it/lib/token';
export declare function isLocalUrl(url: string): boolean;
export declare function findBlockTokens(tokens: Token[], id: string): Token[];
export declare function headingInfo(tokens: Token[], idx: number): {
    level: number;
    title: string;
};
export declare function isExternalHref(href: string): boolean;
export declare function transformLinkToOriginalArticle(opts: {
    root: string;
    currentPath: string;
}): string;
export declare function getHrefTokenAttr(token: Token): string;
export declare function getSrcTokenAttr(token: Token): string;
export declare const PAGE_LINK_REGEXP: RegExp;
export declare function defaultTransformLink(href: string): string;
type TokenWalker = (token: Token, state: {
    commented: boolean;
    index: number;
}) => void | undefined | {
    skip: number;
};
export declare function filterTokens(tokens: Token[], type: string, handler: TokenWalker): void;
export {};
