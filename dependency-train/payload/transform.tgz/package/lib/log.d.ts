export declare enum LogLevels {
    INFO = "info",
    WARN = "warn",
    ERROR = "error",
    DISABLED = "disabled"
}
export declare const log: {
    info: (msg: string) => void;
    warn: (msg: string) => void;
    error: (msg: string) => void;
    LogLevels: typeof LogLevels;
    get: () => Record<LogLevels, string[]>;
    add: (logs: Record<LogLevels, string[]>) => void;
    clear: () => void;
    isEmpty: () => boolean;
};
export type Logger = typeof log;
export default log;
/** Minimal logging contract accepted from embedding applications. */
export type LogConsumer = Pick<Logger, LogLevels.INFO | LogLevels.WARN | LogLevels.ERROR>;
/**
 * Preserve collected diagnostics and forward messages to the caller's logger.
 * @param {LogConsumer} consumer Optional external logger.
 * @returns {Logger} The cached adapter or the default diagnostic collector.
 */
export declare function getLogger(consumer?: LogConsumer): Logger;
