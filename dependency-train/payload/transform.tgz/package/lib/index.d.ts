import type Token from 'markdown-it/lib/token';
import type { OptionsType, OutputType } from './typings';
import type { ContentAudience as VisibilityContentAudience, VisibilityMode as VisibilityContentMode } from './plugins/visibility';
type TokensOptionsType = OptionsType & {
    tokens: true;
};
declare function transform(originInput: string, options: TokensOptionsType): Token[];
declare function transform(originInput: string, options?: OptionsType): OutputType;
export = transform;
declare namespace transform {
    type Options = OptionsType;
    type Output = OutputType;
    type ContentAudience = VisibilityContentAudience;
    type VisibilityMode = VisibilityContentMode;
}
