import type { Token } from 'markdown-it';
/**
 * Detect empty shorthand IDs in terminal attributes using the parser's space separator.
 * @param content - The final text token before attributes are parsed.
 * @param left - Opening attribute delimiter.
 * @param right - Closing attribute delimiter.
 * @returns Whether a shorthand ID block contains an empty ID.
 */
export declare const hasEmptyShorthandId: (content: string, left?: string, right?: string) => boolean;
/**
 * Remove boundary whitespace left by attributes, not spaces inside inline markup.
 * @param token - The heading inline token.
 * @returns Nothing; only boundary text tokens are updated.
 */
export declare const trimHeadingWhitespace: (token: Token) => void;
export declare const CUSTOM_ID_REGEXP: RegExp;
export declare const CUSTOM_ID_EXCEPTION = "[{#T}]";
export declare const getCustomIds: (content: string) => string[] | null;
export declare const removeCustomId: (content: string) => string;
export declare const removeCustomIds: (token: Token) => void;
