import type { MarkdownItPluginOpts } from '../typings';
declare const collect: (input: string, options: MarkdownItPluginOpts & {
    singlePage: boolean;
}) => string | undefined;
export = collect;
