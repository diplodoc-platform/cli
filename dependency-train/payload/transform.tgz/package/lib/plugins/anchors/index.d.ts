import type { MarkdownItPluginCb } from '../typings';
interface Options {
    leftDelimiter?: string;
    rightDelimiter?: string;
    extractTitle?: boolean;
    supportGithubAnchors?: boolean;
    disableCommonAnchors?: boolean;
    useCommonAnchorButtons?: boolean;
    transformLink: (v: string) => string;
    getPublicPath?: (options: Options, v?: string) => string;
}
declare const index: MarkdownItPluginCb<Options>;
export = index;
