import type { Lang } from '../typings';
export { CUSTOM_ID_REGEXP, CUSTOM_ID_EXCEPTION } from './custom-id';
export declare const ANCHOR_TITLES: Record<Lang, string>;
