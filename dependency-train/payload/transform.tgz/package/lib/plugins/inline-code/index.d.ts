import type { MarkdownItPluginCb } from '../../typings';
declare const inlineCode: MarkdownItPluginCb;
export = inlineCode;
