import type { Lang } from '../typings';
export declare const LANG_TOKEN_DESCRIPTION: Record<Lang, string>;
export declare const LANG_TOKEN_LABEL: Record<Lang, string>;
