import type { MarkdownItPluginCb } from './typings';
declare const _default: MarkdownItPluginCb;
export = _default;
