declare const _default: import("markdown-it").PluginWithOptions<{
    output?: string;
}>;
export = _default;
