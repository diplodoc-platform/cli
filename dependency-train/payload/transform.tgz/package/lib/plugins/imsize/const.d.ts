export declare enum ImsizeAttr {
    Src = "src",
    Alt = "alt",
    Title = "title",
    Width = "width",
    Height = "height",
    Style = "style",
    Inline = "inline"
}
