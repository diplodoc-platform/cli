import type { PluginWithOptions } from 'markdown-it';
import type { ImsizeOptions } from './plugin';
/**
 * Imsize plugin for markdown-it.
 * This plugin overloads original image renderer.
 * Forked from https://github.com/tatsy/markdown-it-imsize
 */
declare const imsize: PluginWithOptions<ImsizeOptions>;
export = imsize;
