import type MarkdownIt from 'markdown-it';
import type ParserInline from 'markdown-it/lib/parser_inline';
export type ImsizeOptions = {
    enableInlineStyling?: boolean;
};
export declare const imageWithSize: (md: MarkdownIt, opts?: ImsizeOptions) => ParserInline.RuleInline;
