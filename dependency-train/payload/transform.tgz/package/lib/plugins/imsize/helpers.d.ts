export declare function parseImageSize(str: string, pos: number, max: number): {
    ok: boolean;
    pos: number;
    width: string;
    height: string;
};
