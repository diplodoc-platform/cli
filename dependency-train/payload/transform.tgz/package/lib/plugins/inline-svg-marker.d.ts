import type { MarkdownItPluginCb } from './typings';
declare const inlineSvgMarker: MarkdownItPluginCb;
export = inlineSvgMarker;
