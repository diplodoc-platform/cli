import type { MarkdownItPluginOpts } from '../typings';
type Options = MarkdownItPluginOpts & {
    destPath: string;
    copyFile: (path: string, dest: string) => void;
    singlePage: boolean;
};
declare const collect: (input: string, options: Options) => string | null;
export = collect;
