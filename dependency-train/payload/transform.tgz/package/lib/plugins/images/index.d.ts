import type { MarkdownItPluginCb, MarkdownItPluginOpts } from '../typings';
import type { ImageOptions, StateCore } from '../../typings';
import type { IDGenerator } from '../utils';
interface ImageOpts extends MarkdownItPluginOpts {
    assetsPublicPath: string;
    inlineSvg?: boolean;
}
interface InlineOptions {
    enabled: boolean;
    maxFileSize: number;
}
interface SVGOpts extends MarkdownItPluginOpts {
    notFoundCb: (s: string) => void;
    imageOpts: ImageOptions;
    svgInline: InlineOptions;
}
type Opts = SVGOpts & ImageOpts & {
    rawContent: (path: string) => string;
    calcPath: (root: string, path: string) => string;
    replaceImageSrc: (state: StateCore, currentPath: string, path: string, imgSrc: string, opts: ImageOpts) => string;
    file: string;
};
declare const index: MarkdownItPluginCb<Opts>;
/**
 * Return inline SVG, or an empty string when the original image must be kept.
 * @param {string | null} content Source SVG.
 * @param {ImageOptions} options Image, parser and diagnostic options.
 * @param {IDGenerator} generateID Generator used for SVG identifier prefixes.
 * @returns {string} Inline markup, or an empty result for the image fallback.
 */
declare function replaceSvgContent(content: string | null, options: ImageOptions, generateID?: IDGenerator): string;
declare const imagesPlugin: typeof index & {
    replaceSvgContent: typeof replaceSvgContent;
};
export = imagesPlugin;
