import type { MarkdownItPluginCb } from './typings';
type CodeOptions = {
    /**
     * Show button to toggle line wrapping of code.
     * @type {boolean}
     * @default false
     */
    codeLineWrapping?: boolean;
};
declare const code: MarkdownItPluginCb<CodeOptions>;
export = code;
