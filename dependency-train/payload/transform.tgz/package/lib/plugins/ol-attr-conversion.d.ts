import type { MarkdownItPluginCb } from '../typings';
export declare const olAttrConversion: MarkdownItPluginCb;
