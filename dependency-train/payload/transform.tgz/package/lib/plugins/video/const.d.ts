import type { VideoFullOptions } from './types';
/** Supported services */
export declare enum VideoService {
    YouTube = "youtube",
    Vimeo = "vimeo",
    Vine = "vine",
    Prezi = "prezi",
    Osf = "osf",
    Yandex = "yandex",
    Vk = "vk",
    Rutube = "rutube",
    url = "url"
}
export declare const defaults: VideoFullOptions;
