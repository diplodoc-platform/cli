import type { VideoUrlFn } from './types';
export declare const videoUrl: VideoUrlFn;
