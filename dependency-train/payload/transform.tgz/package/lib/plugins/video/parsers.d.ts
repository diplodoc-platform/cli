export declare function youtubeParser(url: string): string;
export declare function vimeoParser(url: string): string;
export declare function vineParser(url: string): string;
export declare function preziParser(url: string): string;
export declare function mfrParser(url: string): string;
export declare function yandexParser(url: string): string;
export declare function vkParser(url: string): string;
export declare function rutubeParser(url: string): string;
export declare function parseVideoUrl(service: string, url: string): false | readonly [string, Record<string, string[]> | undefined];
