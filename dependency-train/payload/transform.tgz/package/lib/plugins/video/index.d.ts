import type { PluginWithOptions } from 'markdown-it';
import type { VideoPluginOptions } from './types';
/**
 * Video plugin for markdown-it.
 * Forked from https://github.com/CenterForOpenScience/markdown-it-video/tree/0.6.3
 */
declare const video: PluginWithOptions<VideoPluginOptions>;
export = video;
