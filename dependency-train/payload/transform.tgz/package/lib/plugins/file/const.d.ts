export { FileSpecialAttr, FILE_TO_LINK_ATTRS_MAP, FILE_REQUIRED_ATTRS as REQUIRED_ATTRS, FILE_TOKEN, FILE_KNOWN_ATTRS as KNOWN_ATTRS, FileClassName, FILE_RULE_NAME as RULE_NAME, FileHtmlAttr as LinkHtmlAttr, } from '@diplodoc/file-extension';
export declare const PREFIX = "{% file ";
export declare const PREFIX_LENGTH: number;
