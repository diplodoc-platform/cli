declare const _default: import("markdown-it").PluginWithOptions<import("@diplodoc/file-extension").PluginOptions>;
export = _default;
