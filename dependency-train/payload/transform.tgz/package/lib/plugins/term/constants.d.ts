export declare const BASIC_TERM_REGEXP = "\\[([^\\[]+)\\](\\(\\*(\\w+)\\))";
