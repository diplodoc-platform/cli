import type { MarkdownItPluginCb } from '../typings';
declare const term: MarkdownItPluginCb;
export = term;
