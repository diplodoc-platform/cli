import type StateBlock from 'markdown-it/lib/rules_block/state_block';
import type { MarkdownIt } from '../../typings';
import type { MarkdownItPluginOpts } from '../typings';
export declare function termDefinitions(md: MarkdownIt, options: MarkdownItPluginOpts): (state: StateBlock, startLine: number, endLine: number, silent: boolean) => boolean;
