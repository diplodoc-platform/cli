import type Token from 'markdown-it/lib/token';
import type { Logger } from '../log';
export type { IDGenerator, IDGeneratorStrategy } from '@diplodoc/utils';
export { createIDGenerator, createIDGeneratorByStrategy } from '@diplodoc/utils';
export type MatchTokenFunction = (tokens: Token[], idx: number) => boolean | null | RegExpMatchArray;
export declare const nestedCloseTokenIdxFactory: (tokenName: string, matchOpenToken: MatchTokenFunction, matchCloseToken: MatchTokenFunction) => (tokens: Token[], idx: number, path: string, log: Logger) => number | null;
export declare const сarriage: string;
/**
 * Generates a legacy random ID.
 * @deprecated Use `options.generateID` from plugin context instead.
 * Fallback preserves legacy random behavior without shared counter state.
 * @param prefix - Optional prefix to prepend to the generated ID.
 * @returns Random ID string, optionally prefixed with `${prefix}-`.
 */
export declare function generateID(prefix?: string): string;
export declare function append<T extends Record<string, []>, Key extends keyof T>(target: T, key: Key, ...values: T[Key]): T | undefined;
