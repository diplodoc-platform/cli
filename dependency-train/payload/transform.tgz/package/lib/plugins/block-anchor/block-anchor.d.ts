import type StateCore from 'markdown-it/lib/rules_core/state_core';
import type Token from 'markdown-it/lib/token';
export declare const TOKEN_NAME = "anchor";
export declare function replaceTokens(state: StateCore): void;
export declare function renderTokens(tokens: Token[], idx: number): string;
