import type MarkdownIt from 'markdown-it';
declare const blockAnchor: (md: MarkdownIt) => MarkdownIt;
export = blockAnchor;
