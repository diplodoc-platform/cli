import type { MarkdownItPluginOpts } from '../typings';
import type { ChangelogItem } from './types';
type Options = Pick<MarkdownItPluginOpts, 'path' | 'log'> & {
    changelogs?: ChangelogItem[];
    extractChangelogs?: boolean;
};
declare const collect: (input: string, { path: filepath, log, changelogs, extractChangelogs }: Options) => string;
export = collect;
