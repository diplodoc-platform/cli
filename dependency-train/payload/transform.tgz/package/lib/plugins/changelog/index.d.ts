import type { MarkdownItPluginCb } from '../typings';
interface Options {
    extractChangelogs?: boolean;
}
declare const changelog: MarkdownItPluginCb<Options>;
export = changelog;
