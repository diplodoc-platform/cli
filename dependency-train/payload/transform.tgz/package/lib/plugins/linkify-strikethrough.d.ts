import type { MarkdownIt } from '../typings';
export default function linkifyStrikethrough(md: MarkdownIt): void;
