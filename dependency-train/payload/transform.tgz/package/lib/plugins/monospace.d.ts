import type { MarkdownItPluginCb } from './typings';
declare const monospace: MarkdownItPluginCb;
export = monospace;
