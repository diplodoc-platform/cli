import type { MarkdownItPluginCb } from '../typings';
import type { YfmTablePluginOptions } from './types';
declare const yfmTable: MarkdownItPluginCb<YfmTablePluginOptions>;
export = yfmTable;
