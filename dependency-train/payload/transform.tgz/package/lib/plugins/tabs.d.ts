declare const _default: (md: import("markdown-it"), options?: {
    output?: string;
    generateID?: import("@diplodoc/utils").IDGenerator;
}) => void;
export = _default;
