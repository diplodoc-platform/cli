type Options = {
    root: string;
    path: string;
    singlePage: boolean;
};
declare const collect: (input: string, options: Options) => string | undefined;
export = collect;
