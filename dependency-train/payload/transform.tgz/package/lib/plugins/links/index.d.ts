import type Token from 'markdown-it/lib/token';
import type { Logger } from '../../log';
import type { CacheContext, StateCore } from '../../typings';
import type { MarkdownItPluginCb, MarkdownItPluginOpts } from '../typings';
type Options = {
    hash: string | null;
    file: string;
    state: StateCore;
    opts: object;
    isEmptyLink: boolean;
    tokens: Token[];
    idx: number;
    nextToken: Token;
    href: string;
    currentPath: string;
    log: Logger;
    cache?: CacheContext;
};
interface ProcOpts extends MarkdownItPluginOpts {
    transformLink: (v: string) => string;
    notFoundCb: (v: string) => void;
    needSkipLinkFn: (v: string) => boolean;
    getPublicPath: (options: ProcOpts, v?: string) => string;
}
declare const index: MarkdownItPluginCb<ProcOpts & Options>;
export = index;
