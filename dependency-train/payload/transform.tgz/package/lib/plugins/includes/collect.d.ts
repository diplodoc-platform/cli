import type { IncludeCollectOpts } from './types';
declare function collect(input: string, options: IncludeCollectOpts): string;
export = collect;
