import type { GetFileTokensOpts } from '../../utilsFS';
import type { MarkdownItPluginCb, MarkdownItPluginOpts } from '../typings';
type Options = MarkdownItPluginOpts & GetFileTokensOpts & {
    notFoundCb: (v: string) => void;
    noReplaceInclude: boolean;
};
declare const index: MarkdownItPluginCb<Options>;
export = index;
