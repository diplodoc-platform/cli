import type { PluginWithOptions } from 'markdown-it';
import type { CheckboxOptions } from './checkbox';
/**
 * Checkbox plugin for markdown-it.
 * Forked from https://github.com/mcecot/markdown-it-checkbox
 */
declare const checkbox: PluginWithOptions<CheckboxOptions>;
export = checkbox;
