import type MarkdownIt from 'markdown-it';
import type Core from 'markdown-it/lib/parser_core';
export declare const pattern: RegExp;
export declare const CheckboxTokenType: {
    readonly Checkbox: "checkbox";
    readonly CheckboxOpen: "checkbox_open";
    readonly CheckboxClose: "checkbox_close";
    readonly CheckboxInput: "checkbox_input";
    readonly CheckboxLabel: "checkbox_label";
    readonly CheckboxLabelOpen: "checkbox_label_open";
    readonly CheckboxLabelClose: "checkbox_label_close";
};
export type CheckboxOptions = {
    idPrefix?: string;
    divClass?: string;
    /** @default true */
    disabled?: boolean;
};
export declare const checkboxReplace: (_md: MarkdownIt, opts?: CheckboxOptions) => Core.RuleCore;
