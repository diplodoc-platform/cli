import type { MarkdownItPluginCb } from './typings';
declare const meta: MarkdownItPluginCb;
export = meta;
