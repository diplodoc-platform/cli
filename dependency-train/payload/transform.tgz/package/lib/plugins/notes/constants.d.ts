import type { Lang } from '../typings';
export declare const TITLES: Record<Lang, Record<string, string>>;
