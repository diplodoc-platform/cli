import type { MarkdownItPluginCb } from '../typings';
type NotesPluginParams = {
    notesAutotitle: boolean;
};
declare const index: MarkdownItPluginCb<NotesPluginParams>;
export = index;
