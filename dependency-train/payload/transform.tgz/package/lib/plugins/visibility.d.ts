import type MarkdownIt from 'markdown-it';
import type { MarkdownItPluginCb } from './typings';
export type ContentAudience = 'human' | 'agent';
export type VisibilityMode = ContentAudience | 'preserve';
export interface VisibilityError {
    line: number;
    value: string;
    message: string;
}
export interface VisibilityOptions {
    audience?: VisibilityMode;
    lint?: boolean;
    onError?: (error: VisibilityError) => void;
}
export interface AudienceFilterResult {
    content: string;
    audienceSpecificContent: ContentAudience[];
    originalCharacters: number;
    filteredCharacters: number;
    removedCharacters: number;
    errors: VisibilityError[];
}
/**
 * Creates the audience visibility directive plugin.
 *
 * The `preserve` mode tokenizes both audiences without rendering the directive wrapper. It is
 * intended for source-aware consumers such as the translation pipeline, which retain untouched
 * source ranges around the emitted content tokens.
 *
 * @returns Markdown-it plugin for audience visibility blocks.
 */
export declare function visibility({ audience, lint, onError, }?: VisibilityOptions): MarkdownIt.PluginSimple;
/**
 * Filters Markdown source for one content audience while preserving all unrelated source text.
 *
 * @param markdown Markdown source to filter.
 * @param audience Audience whose content should be retained.
 * @returns Filtered source, detected audiences, diagnostics, and character counts.
 */
export declare function filterAudienceContent(markdown: string, audience: ContentAudience): AudienceFilterResult;
declare const visibilityPlugin: MarkdownItPluginCb;
export default visibilityPlugin;
