import type { Lang } from './typings';
export declare const DEFAULT_LANG: Lang;
