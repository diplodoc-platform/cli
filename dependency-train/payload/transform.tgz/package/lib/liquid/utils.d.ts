export declare function removeIndentBlock(str: string): string;
type Opts = {
    content: string;
    tagStartPos: number;
    tagContent: string;
};
export declare function getPreparedLeftContent({ content, tagStartPos, tagContent }: Opts): string;
export {};
