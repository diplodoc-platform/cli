export declare const NoValue: unique symbol;
export declare function evalExp(exp: string, scope: Record<string, unknown>, strict?: boolean): string[] | number[] | boolean | string | symbol | undefined | ((input: string) => number | string);
declare const _default: (exp: string, scope: Record<string, unknown>, strict?: boolean) => boolean;
export default _default;
