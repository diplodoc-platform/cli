declare const substitutions: (str: string, builtVars: Record<string, unknown>, path?: string) => any;
export = substitutions;
