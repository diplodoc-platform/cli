export declare function getLineNumber(input: string, index: number): number;
export declare function prepareSourceMap(sourceMap: object): import("lodash").Dictionary<string>;
type MoveLinesOptions = {
    start: number;
    end: number;
    offset: number;
    withReplace?: boolean;
};
export type SourceMapApi = ReturnType<typeof createSourceMapApi>;
export declare function createSourceMapApi(sourceMap: Record<number, number>): {
    getSourceMapValue: (i: number) => number;
    moveLines: ({ start, end, offset, withReplace }: MoveLinesOptions) => void;
    removeLines: ({ start, end }: {
        start: number;
        end: number;
    }) => void;
    removeLine: (i: number) => void;
};
export {};
