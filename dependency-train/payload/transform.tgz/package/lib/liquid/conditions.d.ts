declare const _default: (input: string, vars: Record<string, unknown>, path?: string, settings?: {
    sourceMap: Record<number, number>;
    strict?: boolean;
    useLegacyConditions?: boolean;
}) => string;
export = _default;
