import type { Dictionary } from 'lodash';
import type { ArgvSettings } from './services/argv';
declare function liquidSnippet<B extends boolean = false, C = B extends false ? string : {
    output: string;
    sourceMap: Dictionary<string>;
}>(originInput: string, vars: Record<string, unknown>, path?: string, settings?: ArgvSettings & {
    withSourceMap?: B;
}): C;
declare function liquidDocument<B extends boolean = false, C = B extends false ? string : {
    output: string;
    sourceMap: Dictionary<string>;
}>(input: string, vars: Record<string, unknown>, path?: string, settings?: ArgvSettings & {
    withSourceMap?: B;
}): C;
export { liquidDocument, liquidSnippet };
export default liquidDocument;
