declare const _default: (originInput: string, vars: Record<string, unknown>, path?: string, settings?: {
    sourceMap: Record<number, number>;
}) => string;
export = _default;
