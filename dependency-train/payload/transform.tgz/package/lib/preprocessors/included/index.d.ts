import type { MarkdownItPreprocessorCb } from '../../typings';
declare const index: MarkdownItPreprocessorCb<{
    included?: boolean;
}>;
export = index;
