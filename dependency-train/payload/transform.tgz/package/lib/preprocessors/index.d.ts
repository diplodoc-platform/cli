import type { MarkdownIt, MarkdownItPluginOpts, MarkdownItPreprocessorCb } from '../plugins/typings';
import type { PluginOptions } from '../yfmlint';
declare const defaultPreprocessors: MarkdownItPreprocessorCb[];
export default defaultPreprocessors;
export declare function preprocess(content: string, pluginOptions: MarkdownItPluginOpts | PluginOptions | unknown, options?: Partial<MarkdownItPluginOpts> & {
    preprocessors?: MarkdownItPreprocessorCb[];
}, md?: MarkdownIt): string;
