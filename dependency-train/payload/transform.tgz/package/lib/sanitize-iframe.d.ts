import type { Attributes, Tag } from 'sanitize-html';
/**
 * Preserve passive HTML embeds without arbitrary srcdoc or sandbox escapes.
 *
 * @param tagName The parsed iframe tag.
 * @param attributes Untrusted outer attributes.
 * @param sanitizeContent The outer policy applied to embedded markup.
 * @returns The safe outer tag and attributes.
 */
export declare function sanitizeIframe(tagName: string, attributes: Attributes, sanitizeContent?: (html: string) => string): Tag;
/**
 * Validate the complete attribute pair, including after outer attribute filtering.
 *
 * @param attributes Parsed or filtered iframe attributes.
 * @returns Whether the iframe cannot execute scripts or escape its sandbox.
 */
export declare function isPassiveIframe(attributes: Attributes): boolean;
