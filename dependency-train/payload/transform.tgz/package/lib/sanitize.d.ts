import type { CssWhiteList } from './typings';
import sanitizeHtml from 'sanitize-html';
export type SanitizeFunction = (html: string, options?: SanitizeOptions, additionalOptions?: SanitizeOptions) => string;
export interface SanitizeOptions extends sanitizeHtml.IOptions {
    cssWhiteList?: CssWhiteList;
    disableStyleSanitizer?: boolean;
}
export declare const defaultParseOptions: {
    lowerCaseAttributeNames: boolean;
};
export declare const defaultOptions: SanitizeOptions;
export declare function sanitizeStyles(html: string, options: SanitizeOptions): string;
export declare function sanitize(html: string, options?: SanitizeOptions, additionalOptions?: SanitizeOptions): string;
export default sanitize;
