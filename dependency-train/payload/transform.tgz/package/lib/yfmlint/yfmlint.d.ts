import type { LintConfig } from '.';
declare const index: LintConfig;
export = index;
