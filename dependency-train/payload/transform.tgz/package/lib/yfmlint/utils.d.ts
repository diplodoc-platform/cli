import type { Dictionary } from 'lodash';
import type { LintError } from 'markdownlint';
import type { LogLevels } from '../log';
export declare function errorToString(path: string, error: LintError, sourceMap?: Dictionary<string>): string;
export declare function getLogLevel(opts: {
    ruleNames: string[];
    logLevelsConfig: Record<string, LogLevels>;
    defaultLevel: LogLevels;
}): LogLevels;
