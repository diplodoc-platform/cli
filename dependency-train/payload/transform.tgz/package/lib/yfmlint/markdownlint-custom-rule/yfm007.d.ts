import type { Rule } from 'markdownlint';
export declare const yfm007: Rule;
