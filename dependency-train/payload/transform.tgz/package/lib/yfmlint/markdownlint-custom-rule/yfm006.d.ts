import type { Rule } from 'markdownlint';
export declare const yfm006: Rule;
