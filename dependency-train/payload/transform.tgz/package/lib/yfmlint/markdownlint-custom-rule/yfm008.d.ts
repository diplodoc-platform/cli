import type { Rule } from 'markdownlint';
export declare const yfm008: Rule;
