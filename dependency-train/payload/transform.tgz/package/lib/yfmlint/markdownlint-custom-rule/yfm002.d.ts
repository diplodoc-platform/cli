import type { Rule } from 'markdownlint';
export declare const yfm002: Rule;
