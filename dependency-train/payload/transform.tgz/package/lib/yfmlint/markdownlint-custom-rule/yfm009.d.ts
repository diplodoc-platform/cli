import type { Rule } from 'markdownlint';
export declare const yfm009: Rule;
