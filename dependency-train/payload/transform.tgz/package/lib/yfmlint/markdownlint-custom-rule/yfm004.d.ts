import type { Rule } from 'markdownlint';
export declare const yfm004: Rule;
