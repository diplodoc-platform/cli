import type { Dictionary } from 'lodash';
import type { Rule } from 'markdownlint';
import type { LogLevels, Logger } from '../log';
import type { Options } from './typings';
declare function yfmlint(opts: Options): void;
export = yfmlint;
declare namespace yfmlint {
    interface LintMarkdownFunctionOptions {
        input: string;
        path: string;
        sourceMap?: Dictionary<string>;
    }
    interface PluginOptions {
        log: Logger;
        path?: string;
        disableLint?: boolean;
        lintMarkdown?: (opts: LintMarkdownFunctionOptions) => void;
        [key: string]: unknown;
    }
    interface LintConfig {
        default?: boolean;
        'log-levels': Record<string, LogLevels>;
        [x: string]: unknown;
    }
    type LintRule = Rule;
}
