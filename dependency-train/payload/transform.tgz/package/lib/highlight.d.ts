import type { HighlightLangMap } from './typings';
declare const _default: (langs?: HighlightLangMap) => (str: string, lang: string) => string;
export = _default;
