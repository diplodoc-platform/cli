import type * as Svgo from 'svgo' with { 'resolution-mode': 'import' };
export declare const optimize: (input: string, config?: import("svgo/browser").Config | undefined) => import("svgo/browser").Output;
export type PluginConfig = Svgo.PluginConfig;
