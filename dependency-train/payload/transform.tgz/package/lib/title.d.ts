import type Token from 'markdown-it/lib/token';
declare const _default: (tokens: Token[]) => {
    titleTokens: Token[];
    title: string;
    tokens: Token[];
};
export = _default;
