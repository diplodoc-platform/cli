export type FrontMatter = {
    [key: string]: unknown;
    metadata?: Record<string, unknown>[];
};
export declare const extractFrontMatter: (fileContent: string, filePath?: string) => [FrontMatter, string];
export declare const composeFrontMatter: (frontMatter: FrontMatter, strippedContent: string) => string;
