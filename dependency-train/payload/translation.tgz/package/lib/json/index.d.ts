export type { JSONObject, LinkedJSONObject } from './types';
export { translate } from './translate';
export { linkRefs, unlinkRefs } from './refs';
export declare const jsonSchema: any;
export declare const openapiSchema30: any;
export declare const openapiSchema31: any;
