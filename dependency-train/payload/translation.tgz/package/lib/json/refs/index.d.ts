import type { FileLoader, JSONObject, LinkedJSONObject } from '../types';
/**
 * Replaces parts of resolved by linkRefs JSON tree with original ref definitions.
 * Mutates original data.
 *
 * @param content - The structure to find JSON References within.
 *
 * @returns mutated array/object with resolved refs
 */
export declare function unlinkRefs(content: LinkedJSONObject): Promise<JSONObject>;
/**
 * Resolves JSON References defined within the provided object.
 * Mutates original data.
 * Skips circular references.
 *
 * @param content - The structure to find JSON References within.
 * @param location - Absolute path to provided structure for relative refs resolving.
 * @param loader - File loader for relative refs resolving.
 *
 * @returns mutated array/object with resolved refs
 */
export declare function linkRefs(content: JSONObject, location: string, loader: FileLoader): Promise<JSONObject>;
