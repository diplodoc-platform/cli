import type { JSONObject } from 'src/json';
export declare class WalkerContext {
    readonly ancestors: JSONObject[];
    location: string;
    constructor(location?: string, ancestors?: WalkerContext['ancestors']);
    shouldVisit(value: JSONObject): boolean;
    copy(): WalkerContext;
}
