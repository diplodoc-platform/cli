import type { FileLoader, JSONObject, RefDefinition } from '../types';
export declare class RefDetails {
    private readonly uri;
    private readonly loader;
    get path(): string;
    get fragment(): string;
    constructor(location: string, def: RefDefinition, loader: FileLoader);
    document(): Promise<JSONObject<unknown>>;
    value(): Promise<JSONObject>;
}
