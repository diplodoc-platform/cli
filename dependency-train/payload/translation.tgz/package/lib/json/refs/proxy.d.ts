import type { JSONObject, RefDefinition, RefLink } from '../types';
export declare const Ref: unique symbol;
export declare const Disabled: unique symbol;
/**
 * Creates a special proxy which stores information about original ref definition
 * and resolved ref.
 * Allows to mutate data in ref and ref definition.
 *
 * @param ref - Resolved reference.
 * @param def - Reference definition.
 *
 * @returns Merged proxy object.
 */
export declare function proxy(ref: JSONObject, def: RefDefinition): JSONObject;
export declare function isProxy(item: unknown): item is RefLink;
export declare function disable(proxy: Container): void;
