import type { JSONObject, RefDefinition } from '../types';
import * as URI from 'uri-js';
/**
 * Returns whether the argument represents a JSON Pointer.
 *
 * A string is a JSON Pointer if the following are all true:
 *
 *   * The string is of type `String`
 *   * The string must be empty, `#` or start with a `/` or `#/`
 *
 * @param ptr - The string to check
 *
 * @returns the result of the check
 *
 * @throws when the provided value is invalid and the `throwWithDetails` argument is `true`
 *
 * @see {@link https://tools.ietf.org/html/rfc6901#section-3}
 */
export declare function isPtr(ptr: any): void;
/**
 * Returns an array of path segments for the provided JSON Pointer.
 *
 * @param ptr - The JSON Pointer
 *
 * @returns the path segments
 *
 * @throws if the provided `ptr` argument is not a JSON Pointer
 */
export declare function pathFromPtr(ptr: string): string[];
/**
 * Returns a JSON Pointer for the provided array of path segments.
 *
 * **Note:** If a path segment in `path` is not a `String`, it will be converted to one using `JSON.stringify`.
 *
 * @param path - The array of path segments
 * @param [hashPrefix=true] - Whether or not create a hash-prefixed JSON Pointer
 *
 * @returns the corresponding JSON Pointer
 *
 * @throws if the `path` argument is not an array
 */
export declare function pathToPtr(path: string[], hashPrefix?: boolean): string;
export declare function parseURI(uri: string): URI.URIComponents;
export declare function isRefLike(obj: any): obj is RefDefinition;
export declare function get(obj: JSONObject, path: string[]): JSONObject;
