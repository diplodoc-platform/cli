import type { JSONType, KeywordCxt } from 'ajv';
import type { Hash } from 'src/hash';
import type { ConsumerOptions } from 'src/consumer';
type Schema = 'md' | 'text';
export declare function genCode(ontranslate: (text: string, schema: Schema) => string): (cxt: KeywordCxt) => void;
declare function extract(hash: Hash, options: ConsumerOptions): {
    keyword: string;
    type: JSONType[];
    code: (cxt: KeywordCxt) => void;
};
declare function compose(units: string[]): {
    keyword: string;
    type: JSONType[];
    code: (cxt: KeywordCxt) => void;
};
export declare const translate: {
    extract: typeof extract;
    compose: typeof compose;
};
export {};
