export declare function readPath(path: string): {
    path: string;
    data: any;
};
export declare function normalizePath(path: string): string;
export declare function absolutePath(location: string, root?: string): string;
export declare function isObject<T = unknown>(object: unknown): object is Container<T>;
export declare function isString(string: unknown): string is string;
export declare function keys(target: Hash): string[];
export declare function uniq<T = string>(array: T[]): T[];
export declare function tail<T>(array: T[], offset?: number): T;
