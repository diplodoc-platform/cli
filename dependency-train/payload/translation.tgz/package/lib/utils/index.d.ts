export declare function token(type: string, props?: Hash): import("markdown-it/lib/token") & Hash<any>;
export declare function find(type: string, tokens: Token[], idx: number): Token | null;
export declare function replace(source: string, units: string[], render?: (value: string, offset: number) => string): [string, boolean];
