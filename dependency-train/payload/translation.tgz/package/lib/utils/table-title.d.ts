/**
 * Split a standalone wide-table attribute into its protected edges and title.
 * @param content Standalone attribute source.
 * @returns Protected prefix, title and suffix, or undefined for unsupported input.
 */
export declare function tableTitleParts(content: string): [string, string, string] | undefined;
/**
 * Identify units that need title-specific validation, including nested units.
 * @param source Markdown skeleton.
 * @param units Extracted XLIFF source units.
 * @returns One group of unit indices per title value.
 */
export declare function tableTitleUnitIds(source: string, units: string[]): number[][];
/**
 * Reject unrepresentable translated titles; never pretend backslashes escape YFM.
 * @param source Markdown skeleton.
 * @returns Context-aware replacement validator.
 */
export declare function tableTitleValidator(source: string): (value: string, offset: number) => string;
