export declare function trim(part: Token[]): Token[];
export declare function split(tokens: Token[], compact?: boolean): Token[][];
