import { CriticalProcessingError } from './error';
export { CriticalProcessingError };
export type ConsumerOptions = {
    compact?: boolean;
    code?: CodeProcessing;
};
export declare enum CodeProcessing {
    NO = "no",
    ALL = "all",
    PRECISE = "precise",
    ADAPTIVE = "adaptive"
}
export declare class Consumer {
    gap: number;
    lines: number[];
    compact: boolean;
    /**
     * Original content
     */
    readonly source: string;
    content: string;
    code: CodeProcessing | undefined;
    hash: (tokens: Token[]) => string;
    /**
     * Problems that left a part of the content untranslated
     * without failing the extraction.
     */
    warnings: string[];
    /**
     * Current window end.
     */
    get limit(): number;
    /**
     * Current window lines range mapped to sourcelines.
     */
    get range(): {
        start: number;
        end: number;
    };
    /**
     * Current consumer position.
     * Also current window start.
     */
    private cursor;
    private limits;
    constructor(content: string, options: ConsumerOptions, hash: (tokens: Token[]) => string);
    process: (tokens: Token | Token[], window?: [number, number] | null) => {
        part: Token[];
        past: string;
    }[];
    consume: (part: Token[], past?: string) => {
        part: Token[];
        past: string;
    } | null;
    setWindow(map: [number, number] | null | undefined, gap?: number): void;
    unsetWindow(): void;
    private erule;
    private drop;
    private line;
}
