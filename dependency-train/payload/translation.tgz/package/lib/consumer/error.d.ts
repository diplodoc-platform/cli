import type { Consumer } from './index';
type Position = {
    start: number;
    end: number;
};
export declare class CriticalProcessingError extends Error {
    source: Position;
    content: string;
    match: string;
    get info(): string;
    constructor(source: Position, content: string, match: string);
    fill(ctx: Consumer): void;
}
export {};
