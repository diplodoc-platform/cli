import type { Gobbler } from 'src/skeleton/types';
export declare function eruler<T extends string | Token>(content: string, [start, end]: [number, number], tokens: T[], action: Gobbler<T>): number[];
export declare const skip: Gobbler;
export declare const gobble: Gobbler<Token>;
declare function isContentful(token: Token): boolean;
export declare function dropUselessTokens(tokens: Token[], accurate?: boolean): Token[][];
type TokenGroup = {
    role: string;
    type: string;
    child: (Token | TokenGroup)[];
    parent?: TokenGroup;
    closed: boolean;
};
export declare function head(tokens: (TokenGroup | Token)[], value?: TokenGroup | Token): Token | TokenGroup;
export declare function tail(tokens: (TokenGroup | Token)[], value?: TokenGroup | Token): Token | TokenGroup;
export declare function splitByContent(grouped: (Token | TokenGroup)[], hasContent?: typeof isContentful): Token[][];
export {};
