import type { Gobbler, NonEmptyString } from 'src/skeleton/types';
export declare const search: Gobbler<NonEmptyString>;
