export type Hash = ReturnType<typeof hash>;
export type IdOptions = {
    /**
     * Restart placeholder ids (`g-N`/`x-N`) for every unit instead of
     * numbering them through the document.
     *
     * Unit texts are used as translation cache keys; with document-wide
     * numbering a unit's text depends on the markup extracted above it,
     * so adding one link at the top of a file changes every unit below.
     * Off by default: the XLIFF handed to external tools keeps its
     * document-wide ids.
     */
    unitLocalIds?: boolean;
};
type Props = IdOptions & {
    compact?: boolean;
};
export declare function hash({ compact, unitLocalIds }?: Props): {
    (tokens: Token[]): string;
    segments: string[];
};
export {};
