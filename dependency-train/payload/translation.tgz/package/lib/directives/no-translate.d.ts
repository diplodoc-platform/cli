import type MarkdownIt from 'markdown-it';
interface NoTranslateOptions {
    mode?: 'render' | 'translate';
}
export declare function noTranslate(options?: NoTranslateOptions): MarkdownIt.PluginSimple;
export {};
