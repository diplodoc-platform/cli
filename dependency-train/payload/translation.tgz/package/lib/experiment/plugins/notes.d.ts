import type MarkdownIt from 'markdown-it';
export declare function note(md: MarkdownIt): void;
