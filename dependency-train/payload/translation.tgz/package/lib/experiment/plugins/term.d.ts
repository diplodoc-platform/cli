import type MarkdownIt from 'markdown-it';
export declare function term(md: MarkdownIt): void;
