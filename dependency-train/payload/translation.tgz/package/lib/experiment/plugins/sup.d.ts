import type MarkdownIt from 'markdown-it';
export declare function sup(md: MarkdownIt): void;
