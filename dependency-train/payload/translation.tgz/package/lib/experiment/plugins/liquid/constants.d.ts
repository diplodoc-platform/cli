export declare enum FragmentType {
    Variable = "variable",
    Operator = "operator"
}
export declare const VARS_RE: RegExp;
export declare const CONDITION_RE: RegExp;
export declare const INCLUDE_RE: RegExp;
