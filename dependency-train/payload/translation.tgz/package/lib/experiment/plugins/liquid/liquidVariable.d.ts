import type MarkdownIt from 'markdown-it';
export declare function liquidVariable(md: MarkdownIt): void;
