import type MarkdownIt from 'markdown-it';
export declare function liquidOperator(md: MarkdownIt): void;
