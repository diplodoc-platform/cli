import type MarkdownIt from 'markdown-it';
export declare function linksTemplates(md: MarkdownIt): void;
