import type MarkdownIt from 'markdown-it';
export declare function changelog(md: MarkdownIt): void;
