import type MarkdownIt from 'markdown-it';
export declare function anchor(md: MarkdownIt): void;
