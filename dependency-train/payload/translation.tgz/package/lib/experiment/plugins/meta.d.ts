import type markdownIt from 'markdown-it';
export declare function meta(md: markdownIt): void;
