import type MarkdownIt from 'markdown-it';
export declare function cut(md: MarkdownIt): void;
