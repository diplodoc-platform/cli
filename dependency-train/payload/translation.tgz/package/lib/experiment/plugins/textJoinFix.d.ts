import type MarkdownIt from 'markdown-it';
export declare function textJoinFix(md: MarkdownIt): void;
