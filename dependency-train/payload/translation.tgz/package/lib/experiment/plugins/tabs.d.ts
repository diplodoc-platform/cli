import type MarkdownIt from 'markdown-it';
export declare function tabs(md: MarkdownIt): void;
