declare function _exports(md: any, options_: any): void;
export = _exports;
