declare function _exports(options: any): ({
    /**
     * ```python {.cls}
     * for i in range(10):
     *     print(i)
     * ```
     */
    name: string;
    tests: {
        shift: number;
        block: boolean;
        info: (arg0: string) => any;
    }[];
    transform: (tokens: any, i: any) => void;
} | {
    /**
     * bla `click()`{.c} ![](img.png){.d}
     *
     * differs from 'inline attributes' as it does
     * not have a closing tag (nesting: -1)
     */
    name: string;
    tests: {
        shift: number;
        type: string;
        children: ({
            shift: number;
            type: (str: any) => boolean;
            content?: undefined;
            __attrPluginSkip?: undefined;
        } | {
            shift: number;
            type: string;
            content: (arg0: string) => any;
            __attrPluginSkip: undefined;
        })[];
    }[];
    transform: (tokens: any, i: any, j: any) => void;
} | {
    /**
     * | h1 |
     * | -- |
     * | c1 |
     *
     * {.c}
     */
    name: string;
    tests: ({
        shift: number;
        type: string;
        content?: undefined;
    } | {
        shift: number;
        type: string;
        content: (arg0: string) => any;
    })[];
    transform: (tokens: any, i: any) => void;
} | {
    /**
     * *emphasis*{.with attrs=1}
     */
    name: string;
    tests: {
        shift: number;
        type: string;
        children: ({
            shift: number;
            nesting: number;
            type?: undefined;
            content?: undefined;
        } | {
            shift: number;
            type: string;
            content: (arg0: string) => any;
            nesting?: undefined;
        })[];
    }[];
    transform: (tokens: any, i: any, j: any) => void;
} | {
    /**
     * - item
     * {.a}
     */
    name: string;
    tests: ({
        shift: number;
        type: string;
        children?: undefined;
    } | {
        shift: number;
        type: string;
        children: ({
            position: number;
            type: string;
            content?: undefined;
        } | {
            position: number;
            type: string;
            content: (arg0: string) => any;
        })[];
    })[];
    transform: (tokens: any, i: any, j: any) => void;
} | {
    /**
     * - nested list
     *   - with double \n
     *   {.a} <-- apply to nested ul
     *
     * {.b} <-- apply to root <ul>
     */
    name: string;
    tests: ({
        shift: number;
        type: (str: any) => boolean;
        content?: undefined;
        children?: undefined;
    } | {
        shift: number;
        type: string;
        content?: undefined;
        children?: undefined;
    } | {
        shift: number;
        type: string;
        content: (arg0: string) => any;
        children: (arr: any) => boolean;
    })[];
    transform: (tokens: any, i: any) => void;
} | {
    /**
     * end of {.block}
     */
    name: string;
    tests: {
        shift: number;
        type: string;
        children: {
            position: number;
            content: (arg0: string) => any;
            type: (t: any) => boolean;
        }[];
    }[];
    transform: (tokens: any, i: any, j: any) => void;
})[];
export = _exports;
