import type MarkdownIt from 'markdown-it';
export declare function attrsPlugin(md: MarkdownIt): void;
