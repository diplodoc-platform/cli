export function getAttrs(str: string, start: int, options: any): 2;
export function addAttrs(attrs: array, token: any): any;
export function hasDelimiters(where: string, options: any): (arg0: string) => any;
export function removeDelimiter(str: any, options: any): any;
export function getMatchingOpeningToken(tokens: any, i: any): any;
export function escapeHtml(str: any): any;
/**
 * Escapes special characters in string s such that the string
 * can be used in `new RegExp`. For example "[" becomes "\\[".
 *
 * @param {string} s Regex string.
 * @return {string} Escaped string.
 */
export function escapeRegExp(s: string): string;
