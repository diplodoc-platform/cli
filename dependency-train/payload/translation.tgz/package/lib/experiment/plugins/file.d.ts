import type MarkdownIt from 'markdown-it';
export declare function filePlugin(md: MarkdownIt): void;
