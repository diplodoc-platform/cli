import type MarkdownIt from 'markdown-it';
export declare function xliffSpecial(md: MarkdownIt): void;
