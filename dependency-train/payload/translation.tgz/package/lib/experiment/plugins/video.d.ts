import type MarkdownIt from 'markdown-it';
export declare function video(md: MarkdownIt): void;
