import type MarkdownIt from 'markdown-it';
export declare function anchors(md: MarkdownIt): void;
