import type { ComposeOptions, ComposeOutput, ExtractOptions, ExtractOutput } from 'src/experiment/adapter/types';
export declare function extract(content: string, options: ExtractOptions): ExtractOutput;
export declare function compose(skeleton: string, xliff: string, options: ComposeOptions): ComposeOutput;
