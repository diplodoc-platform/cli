import type { XmlParserElementChildNode, XmlParserElementNode, XmlParserResult } from 'xml-parser-xo';
export type TranslateOptions = {
    useSource?: boolean;
    parsedXliff?: XmlParserResult;
};
export declare function translate(xliffData: string, skeletonData: string, options?: TranslateOptions): {
    document: string;
    variables: Record<string, string>;
    externalFile: string | undefined;
    originalFile: string;
    sourceLanguage: string;
    targetLanguage: string;
};
export declare function getAttr(node: XmlParserElementNode, attr: string): string;
export declare function findNodeByNamePath(node: XmlParserElementChildNode, names: string[]): XmlParserElementNode | undefined;
