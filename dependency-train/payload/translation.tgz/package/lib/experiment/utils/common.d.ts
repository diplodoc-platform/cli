import type MarkdownIt from 'markdown-it';
import type { TokenExtraMap } from '../types';
import Token from 'markdown-it/lib/token';
export declare function toJson(data: unknown, format?: boolean): string;
export declare function toJsonF(data: unknown): string;
export declare function getExtraToken(tokenExtraMap: TokenExtraMap, token: Token): import("../types").ExtraToken;
export declare function safeSlice(str: string, start?: number, end?: number): string;
export declare function getTokenChildrenPos(tokenExtraMap: TokenExtraMap, children: Token[]): {
    start: number;
    end: number;
};
export declare function floatToken(mdData: string, tokenExtraMap: TokenExtraMap, token: Token): Token[];
export declare function hasTextChildren(token: Token): boolean;
export declare function someTokens(tokens: Token[], check: (token: Token, index: number, tokens: Token[]) => boolean): boolean;
export declare function eachTokens(tokens: Token[], check: (token: Token, index: number, tokens: Token[]) => unknown | true): void;
export declare function printMap(mdData: string, allTokens: Token[], tokenExtraMap: TokenExtraMap): void;
export declare function tabReplace(dataArg: string, tokenExtraMap: TokenExtraMap): {
    data: string;
    revert: (dataArgLocal: string) => string;
};
export declare function variableReplace(dataArg: string): {
    data: string;
    revert: (dataArgLocal: string) => string;
};
export declare function extractLinkTitle(md: MarkdownIt, mdData: string, tokenExtraMap: TokenExtraMap, token: Token, tokens: Token[]): void;
export declare function extractImageTitle(md: MarkdownIt, mdData: string, tokenExtraMap: TokenExtraMap, token: Token, tokens: Token[]): void;
export declare function extractInlineCode(mdData: string, tokenExtraMap: TokenExtraMap, token: Token): void;
export declare function extractFenceLines(mdData: string, tokenExtraMap: TokenExtraMap, token: Token): void;
export declare function skipImageName(mdData: string, tokenExtraMap: TokenExtraMap, token: Token): void;
