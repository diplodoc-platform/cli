import type { TokenExtraMap } from '../types';
import Token from 'markdown-it/lib/token';
export declare function tokenizeYaml(rawYaml: string, tokenExtraMap: TokenExtraMap, level: number): Token;
export declare function yamlVariableReplace(dataArg: string): {
    data: string;
    revert: (dataArgLocal: string) => string;
};
