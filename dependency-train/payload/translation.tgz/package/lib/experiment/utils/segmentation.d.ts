import type { TokenExtraMap } from '../types';
import Token from 'markdown-it/lib/token';
export declare function applySegmentation(mdData: string, inlineToken: Token, tokenExtraMap: TokenExtraMap): Token[];
export declare function trimInlineToken(mdData: string, inlineToken: Token, tokenExtraMap: TokenExtraMap): Token[];
export declare function splitInlineToken(mdData: string, inlineToken: Token, point: number, tokenExtraMap: TokenExtraMap): Token[];
