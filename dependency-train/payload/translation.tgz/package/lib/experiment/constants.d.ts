export declare const SKELETON_EXT = ".skl.md";
export declare const XLIFF_EXT = ".xliff";
export declare const VARS_EXT = ".vars";
export declare const MD_EXT = ".md";
export declare const YamlQuotingTypeQuote: {
    dq: "\"";
    sq: "'";
};
export declare const YamlQuoteQuotingType: {
    '"': string;
    "'": string;
};
export declare const passSymbols: RegExp;
export declare const passTranslation: RegExp;
