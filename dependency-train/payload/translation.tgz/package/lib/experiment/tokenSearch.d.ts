import type { Token } from 'markdown-it';
import type { TokenExtraMap } from './types';
export declare function tokenSearch(mdData: string, tokenExtraMap: TokenExtraMap, allTokens: Token[]): void;
export declare function childrenTokenSearch(mdData: string, tokenExtraMap: TokenExtraMap, tokens: Token[], levelTokenType: string[], startPos: number, level: number): void;
