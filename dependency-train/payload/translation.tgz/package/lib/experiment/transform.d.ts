export interface TransformOptions {
    compact?: boolean;
    showTokens?: boolean;
    showMap?: boolean;
    showRawMap?: boolean;
    showVars?: boolean;
}
export declare function transform(content: string, options?: TransformOptions): {
    skeleton: string;
    variables: Map<string, string>;
    xliff: import("./xliff/xliff").Xliff;
};
