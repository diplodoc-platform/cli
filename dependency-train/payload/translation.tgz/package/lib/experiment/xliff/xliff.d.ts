import type { TransUnitElement } from './elements/TransUnitElement';
interface XliffProps {
    datatype?: string;
    compact?: boolean;
}
export declare class Xliff {
    file: string;
    targetLanguage: string;
    sourceLanguage: string;
    datatype: string;
    skeletonFile?: string;
    compact?: boolean;
    transUnits: TransUnitElement[];
    constructor({ datatype, compact }?: XliffProps);
    setFile(path: string): void;
    setSkeletonFile(path: string): void;
    setSourceLanguage(lang: string): void;
    setTargetLanguage(lang: string): void;
    appendTransUnit(element: TransUnitElement): void;
    toString(): string;
}
export {};
