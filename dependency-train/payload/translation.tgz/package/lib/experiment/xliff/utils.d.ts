export declare function escapeXmlText(text: string): string;
export declare function unescapeXmlText(xmlText: string): string;
export declare function attributesToString(attributes: Record<string, unknown> | undefined): string;
