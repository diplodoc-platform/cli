import type { ReplacePart, TokenExtraMap } from '../types';
import Token from 'markdown-it/lib/token';
import { Xliff } from './xliff';
export declare const buildXliff: (replaceParts: ReplacePart[], tokenExtraMap: TokenExtraMap, mdData: string, compact?: boolean) => Xliff;
export declare function prepareInlineToken(inlineToken: Token, tokenExtraMap: TokenExtraMap, mdData: string): Token[];
export declare function markTokens(tokens: Token[], tokenExtraMap: TokenExtraMap): void;
