import { BaseElement } from './BaseElement';
export declare class GElement extends BaseElement {
    tag: string;
    equivText: string;
    constructor(id: string, equivText: string);
    toString(): string;
}
