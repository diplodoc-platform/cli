import { BaseElement } from './BaseElement';
export declare class TransUnitElement extends BaseElement {
    tag: string;
    constructor(id: string);
    toString(): string;
}
