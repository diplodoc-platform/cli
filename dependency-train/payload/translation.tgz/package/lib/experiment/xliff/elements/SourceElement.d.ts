import { BaseElement } from './BaseElement';
export declare class SourceElement extends BaseElement {
    tag: string;
    constructor({ compact }?: {
        compact: boolean;
    });
}
