export declare class BaseElement {
    tag: string;
    children: BaseElement[];
    compact?: boolean;
    attrs: Record<string, string>;
    setAttr(key: string, value: string): void;
    appendElement(element: BaseElement): void;
    toString(attrs?: Record<string, unknown>): string;
}
