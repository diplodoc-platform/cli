import { BaseElement } from './BaseElement';
export declare class XElement extends BaseElement {
    tag: string;
    equivText: string;
    constructor(id: string, equivText: string);
    toString(): string;
    appendElement(): void;
}
