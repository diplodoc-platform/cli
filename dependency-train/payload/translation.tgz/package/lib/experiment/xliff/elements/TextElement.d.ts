import { BaseElement } from './BaseElement';
export declare class TextElement extends BaseElement {
    text: string;
    constructor(text: string);
    setAttr(): void;
    appendElement(): void;
    toString(): string;
}
