import type { Options } from 'markdown-it';
import type MarkdownIt from 'markdown-it';
import type Token from 'markdown-it/lib/token';
import Renderer from 'markdown-it/lib/renderer';
export declare enum CustomRendererLifeCycle {
    BeforeRender = 0,
    AfterRender = 1,
    BeforeInlineRender = 2,
    AfterInlineRender = 3
}
export type CustomRendererParams<S = {}> = {
    hooks?: CustomRendererHooks;
    rules?: Renderer.RenderRuleRecord;
    state?: S;
};
export type CustomRendererHooks = Record<string, CustomRendererHook | CustomRendererHook[]>;
export interface CustomRendererHook {
    (parameters: CustomRendererHookParameters): string;
}
export type CustomRendererHookParameters = {
    tokens: Token[];
    options: Options;
    env: unknown;
    map?: [number, number] | null;
    rendered?: string[];
};
type SourceMap = [number, number];
export declare class CustomRenderer<State = {}, Md extends MarkdownIt = MarkdownIt> extends Renderer {
    readonly state: State;
    readonly md: Md;
    protected hooks: Map<CustomRendererLifeCycle, CustomRendererHook[]>;
    constructor({ hooks, rules, state }: CustomRendererParams<State>, parser: Md);
    setRules(rules: Renderer.RenderRuleRecord): void;
    setHooks(hooks: CustomRendererHooks): void;
    hook(cycle: CustomRendererLifeCycle, hook: CustomRendererHook | CustomRendererHook[]): void;
    render(tokens: Token[], options: Options, env: unknown): string;
    renderInline(tokens: Token[], options: Options, env: unknown, map: SourceMap | null, inline: Token): string;
    runHooks(cycle: CustomRendererLifeCycle, parameters: CustomRendererHookParameters): string;
    processToken(tokens: Token[], i: number, options: Options, env: unknown): string;
}
export declare function customRenderer<State = {}, Md extends MarkdownIt = MarkdownIt>(parser: Md, parameters?: CustomRendererParams<State>): void;
export {};
