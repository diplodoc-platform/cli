import type MdIt from 'markdown-it';
export default function (md: MdIt): void;
