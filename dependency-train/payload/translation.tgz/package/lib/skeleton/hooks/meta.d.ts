import type { CustomRenderer } from 'src/renderer';
import type { Consumer } from 'src/consumer';
import type MarkdownIt from 'markdown-it';
type MarkdownItWithMeta = MarkdownIt & {
    meta: {};
};
export declare function meta(this: CustomRenderer<Consumer, MarkdownItWithMeta>): string;
export {};
