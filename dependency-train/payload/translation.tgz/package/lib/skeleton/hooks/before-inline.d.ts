import type { CustomRendererHookParameters } from 'src/renderer';
type InlineHookParameters = CustomRendererHookParameters & {
    inline?: Token;
};
export declare function beforeInline(parameters: InlineHookParameters): string;
export {};
