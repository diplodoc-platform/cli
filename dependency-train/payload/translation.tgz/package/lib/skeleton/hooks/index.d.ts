import { afterInline } from './after-inline';
import { beforeInline } from './before-inline';
import { image } from './image';
export declare const hooks: {
    0: (typeof image)[];
    3: (typeof afterInline)[];
    2: (typeof beforeInline)[];
};
