import type { CustomRenderer, CustomRendererHookParameters } from 'src/renderer';
import type { Consumer } from 'src/consumer';
export declare function afterInline(this: CustomRenderer<Consumer>, parameters: CustomRendererHookParameters): string;
