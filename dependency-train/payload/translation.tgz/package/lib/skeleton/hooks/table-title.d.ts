import type { CustomRendererHookParameters } from 'src/renderer';
/**
 * Extract human-readable titles from standalone wide-table attributes only.
 * @returns No rendered output; the hook updates inline tokens.
 */
export declare function tableTitle({ tokens }: CustomRendererHookParameters): string;
