import type { CustomRendererHookParameters } from 'src/renderer';
export declare function image(parameters: CustomRendererHookParameters): string;
