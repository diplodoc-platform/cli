import type { ConsumerOptions } from 'src/consumer';
import type { Hash } from 'src/hash';
export type SkeletonOptions = ConsumerOptions;
/**
 * `warnings` receives problems that left a part of the content untranslated
 * without failing the extraction.
 */
export declare function skeleton(markdown: string, options?: SkeletonOptions, hash?: Hash, warnings?: string[]): string;
