import type { TokenSubType, TokenType } from './token';
export type Configuration = {
    specification?: Specification;
};
export type Specification = Array<SpecificationEntry>;
export type SpecificationEntry = [RegExp, TokenType, TokenSubType] | [RegExp, TokenType];
export type TokenizerGenerator = Generator<Token | null, void, Token | undefined>;
export declare class Liquid implements TokenizerGenerator {
    static escape(content: string): string;
    static unescape(content: string): string;
    private input;
    private cursor;
    private specification;
    constructor(input: string, configuration?: Configuration);
    tokenize(this: TokenizerGenerator & this): Token[];
    [Symbol.iterator](this: TokenizerGenerator & this): Generator<Token, void, unknown>;
    next(): IteratorResult<Token | null>;
    return(): IteratorResult<Token | null, any>;
    throw(): IteratorResult<Token>;
    private match;
    private done;
}
