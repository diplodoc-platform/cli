import type { Fixtures } from './fixture';
declare const condition: Fixtures;
export { condition };
declare const _default: {
    condition: Fixtures;
};
export default _default;
