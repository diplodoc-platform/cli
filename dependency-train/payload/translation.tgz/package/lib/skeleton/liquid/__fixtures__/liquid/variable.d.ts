import type { Fixtures } from './fixture';
declare const variable: Fixtures;
export { variable };
declare const _default: {
    variable: Fixtures;
};
export default _default;
