import type { Fixtures } from './fixture';
declare const text: Fixtures;
export { text };
declare const _default: {
    text: Fixtures;
};
export default _default;
