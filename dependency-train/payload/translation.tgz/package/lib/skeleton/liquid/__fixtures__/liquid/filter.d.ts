import type { Fixtures } from './fixture';
declare const filter: Fixtures;
export { filter };
declare const _default: {
    filter: Fixtures;
};
export default _default;
