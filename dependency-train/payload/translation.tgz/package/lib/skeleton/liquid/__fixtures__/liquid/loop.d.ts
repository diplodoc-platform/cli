import type { Fixtures } from './fixture';
declare const loop: Fixtures;
export { loop };
declare const _default: {
    loop: Fixtures;
};
export default _default;
