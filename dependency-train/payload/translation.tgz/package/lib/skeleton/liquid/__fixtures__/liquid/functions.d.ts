import type { Fixtures } from './fixture';
declare const functions: Fixtures;
export { functions };
declare const _default: {
    functions: Fixtures;
};
export default _default;
