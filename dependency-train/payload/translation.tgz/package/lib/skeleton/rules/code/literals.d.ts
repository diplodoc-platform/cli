/**
 * String literal conventions of a fence language: enough to tell a comment
 * marker inside a literal from a real comment without a full lexer.
 */
export type Literals = {
    /** Quote characters that delimit literals. */
    quotes: string;
    /** Quotes whose literals may span lines. */
    multiline: string;
    /** Quotes where a backslash escapes the next character. */
    escapes: string;
    /** `"""` and `'''` open multi-line literals. */
    triple?: boolean;
    /** Heredoc operator; the second group is the terminator word. */
    heredoc?: RegExp;
    /** Yaml block scalars (`key: |`): the indented lines below are one literal. */
    blockScalars?: boolean;
};
export declare const CLIKE: Literals;
export declare const GO: Literals;
export declare const RUST: Literals;
export declare const SHELL: Literals;
export declare const YAML: Literals;
export declare const PYTHON: Literals;
export declare const SQL: Literals;
export declare const RUBY: Literals;
export declare const PERL: Literals;
export declare const PHP: Literals;
export declare const LUA: Literals;
/** Haskell, Elm, Ada: `'` is a prime or a character, `"` a one-line string. */
export declare const DOUBLE: Literals;
export declare const TOML: Literals;
/** Configs and the rest: one-line strings in either quote. */
export declare const PLAIN: Literals;
export type Marker = {
    index: number;
    length: number;
};
/**
 * Finds comment markers outside string literals. Literals may span lines
 * (template strings, docstrings, shell and sql strings, heredocs, yaml block
 * scalars), so the scanner keeps its state for the whole block.
 */
export declare class CommentScanner {
    private readonly marker;
    private readonly literals;
    /** Delimiter of the open literal: a quote, a backtick or a triple quote. */
    private quote;
    private heredoc;
    /** Indent of the yaml line that opened a block scalar. */
    private block;
    constructor(marker: RegExp | undefined, literals: Literals);
    /**
     * The comment marker of the line, or null when the line has none
     * or is a literal as a whole.
     */
    comment(line: string): Marker | null;
    /**
     * Walks the line up to the first marker outside literals. Returns the
     * marker and the code before it with literal characters blanked out.
     */
    private scan;
    /**
     * Inside a literal: skips an escaped or doubled quote, or closes the literal.
     * Returns the last consumed index.
     */
    private closeLiteral;
    /**
     * Outside a literal: opens one at a quote that starts a literal.
     * Returns the last consumed index.
     */
    private openLiteral;
    /**
     * Whether the quote at `index` starts a literal. An apostrophe inside or
     * after a word (`don't`, `users'`) does not, unless the word is a literal
     * prefix (`f'...'`); a one-line apostrophe literal must also end on the
     * line, or it is a lifetime (`&'a str`). Any other quote that does not end
     * on the line must begin where a literal may, otherwise it is an inch mark.
     */
    private opens;
    /**
     * A one-line literal does not survive its line: an unterminated one is a
     * typo or a continuation, not a reason to hide the comments below.
     */
    private endLine;
    /**
     * The terminator is read from the raw code (`<<'EOF'` quotes it), the
     * masked code tells an operator from `"<<EOF"` inside a literal.
     */
    private openHeredoc;
    private insideHeredoc;
    private openBlockScalar;
    private insideBlockScalar;
}
