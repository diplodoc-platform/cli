/**
 * Exposes human-readable labels of a mermaid diagram: notes, messages and aliases
 * of sequence diagrams, node and edge labels of flowcharts, and the title of any diagram.
 * Identifiers, directives (`%%{init}%%`), comments and styling stay untouched.
 */
export declare function mermaid(content: string): Generator<Token>;
