/**
 * Half-open [from, to) range of translatable text inside a line.
 */
export type Range = [number, number];
export declare function hasLetters(text: string): boolean;
/**
 * Lines of the code without trailing whitespace (and `\r`): it never carries
 * text and never gets into a skip, so the matching stays simple.
 */
export declare function lines(content: string): string[];
/**
 * Turns a line of code into consumer tokens: every text range becomes a translatable
 * `text` token, and the code between the ranges becomes a verbatim `fake` token to skip.
 *
 * Skipping the exact bytes keeps the consumer cursor right before the text, so a label
 * that repeats an identifier earlier on the same line (`participant RPC as RPC`) never
 * replaces the identifier.
 *
 * Leading whitespace is never part of a skip token: markdown-it strips container
 * indentation from fenced code, so the token content and the source may differ there.
 */
export declare function lineTokens(line: string, ranges: Range[]): Generator<Token>;
