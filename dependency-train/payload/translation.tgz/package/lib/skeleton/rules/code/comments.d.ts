import type { Literals } from './literals';
export type CodeHandler = (content: string) => Generator<Token>;
/**
 * What an angle-bracket word means in a language: a placeholder (`any`), a placeholder
 * only when it reads as prose because bare words are generics (`prose`), or a tag (`none`).
 */
export type Placeholders = 'any' | 'prose' | 'none';
export type CodeSyntax = {
    /**
     * Line comment marker. It counts only at line start or after whitespace,
     * so `"#fff"`, `https://` and `a--b` stay code.
     */
    comment?: RegExp;
    placeholders: Placeholders;
    literals: Literals;
};
/**
 * Comment, placeholder and literal conventions of a fence language.
 * Unknown languages expose placeholders only.
 */
export declare function codeSyntax(lang: string): CodeSyntax;
/**
 * Tells a human-readable comment from commented-out code, directives and separators.
 *
 * The heuristic errs on the side of code: a skipped comment stays as is,
 * while a translated statement breaks the example once uncommented.
 */
export declare function isProse(text: string): boolean;
/**
 * Exposes placeholders from code and the text of line comments,
 * leaving commented-out code with its placeholders only.
 */
export declare function comments(syntax: CodeSyntax): CodeHandler;
