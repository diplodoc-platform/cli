import type { CodeHandler } from './comments';
/**
 * Handlers of the precise mode, kept as they always were:
 * comments are translated in shell fences only.
 */
export declare function precise(lang: string): CodeHandler;
