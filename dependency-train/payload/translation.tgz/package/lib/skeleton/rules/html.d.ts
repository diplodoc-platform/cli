import type { RenderRuleRecord } from 'markdown-it/lib/renderer';
export declare const html: RenderRuleRecord;
