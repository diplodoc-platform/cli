import type Renderer from 'markdown-it/lib/renderer';
export declare const text: Renderer.RenderRuleRecord;
