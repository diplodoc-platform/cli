declare function generateBreak(tokens: Token[], i: number): string;
export declare const breaks: {
    hardbreak: typeof generateBreak;
    softbreak: typeof generateBreak;
};
export {};
