export declare const image: {
    image_open: typeof imageOpen;
    image_close: typeof imageClose;
};
declare function imageOpen(tokens: Token[], idx: number): string;
declare function imageClose(tokens: Token[], idx: number): string;
export {};
