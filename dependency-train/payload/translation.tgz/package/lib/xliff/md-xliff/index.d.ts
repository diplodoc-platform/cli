export declare function render(tokens: Token[], unitId: number, compact?: boolean, unitLocalIds?: boolean): string;
