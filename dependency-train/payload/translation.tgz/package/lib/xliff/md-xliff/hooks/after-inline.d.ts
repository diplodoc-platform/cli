import type { CustomRendererHookParameters } from 'src/renderer';
export declare function afterInline(parameters: CustomRendererHookParameters): string;
