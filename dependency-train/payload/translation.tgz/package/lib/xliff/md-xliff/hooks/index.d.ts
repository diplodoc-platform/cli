import { afterInline } from './after-inline';
export declare const hooks: {
    3: (typeof afterInline)[];
};
