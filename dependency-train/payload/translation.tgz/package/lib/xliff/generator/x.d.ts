export type GenerateXParams = {
    ctype: string;
    equivText: string;
} & {
    [prop: string]: string;
};
export declare function generateX(parameters: GenerateXParams): string;
export declare function resetXIds(): void;
