import type countries from '@shellscape/i18n-iso-countries';
export type TemplateOptions = {
    source: LanguageLocale;
    target: LanguageLocale;
};
export type LanguageLocale = {
    language: Language;
    locale: countries.Alpha2Code;
};
declare const _languagesList: string[];
export type Language = (typeof _languagesList)[number];
export declare function template(units: string[], { source, target }: TemplateOptions): string;
export {};
