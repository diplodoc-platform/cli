export type TransUnitParams = {
    target?: string;
    targetLangLocale?: string;
    source?: string;
    sourceLangLocale?: string;
    compact?: boolean;
    id: number;
};
export declare function transunit(parameters: TransUnitParams): string;
