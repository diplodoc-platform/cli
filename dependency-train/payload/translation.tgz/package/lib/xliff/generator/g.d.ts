export type OpenGParams = {
    ctype: string;
    equivText: string;
    xBegin: string;
    xEnd: string;
} & {
    [prop: string]: string;
};
export declare function generateOpenG(parameters: OpenGParams): string;
export declare function generateCloseG(): string;
export declare function resetGIds(): void;
