export declare function snakeCase(key: string): string;
