import type { XLFToken } from '../token';
export type XLFMDRendererRuleSet = {
    text: XLFMDRendererRule;
    [key: string]: XLFMDRendererRule;
};
export type XLFMDRendererRule = (token: XLFToken) => string;
export declare class XLFMDRenderer {
    rules: XLFMDRendererRuleSet;
    constructor();
    render(tokens: XLFToken[]): string;
    text(token: XLFToken): string;
    tag(token: XLFToken): string;
    g(token: XLFToken): string;
    x(token: XLFToken): string;
}
export declare function render(tokens: XLFToken[]): string;
