import type { XLFToken } from 'src/xliff/token';
export type ParseOptions = {
    useSource?: boolean;
};
export declare function parse(xliff: string | string[], options?: ParseOptions): Array<Array<XLFToken>>;
