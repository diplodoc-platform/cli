export type XLFToken = XLFTextToken | XLFTagToken;
export type XLFTextToken = {
    type: 'text';
    data: string;
};
export type NodeTypes = 'open' | 'close' | 'self-closing';
export type XLFTagToken = {
    type: 'tag';
    data: string;
    nodeType: NodeTypes;
    begin: string;
    end: string;
    syntax?: string;
    equivText?: string;
};
export declare function isXLFTextToken(token: XLFToken): token is XLFTextToken;
export declare function isXLFTagToken(token: XLFToken): token is XLFTagToken;
