export declare function validate(target: 'ExtractOptions' | 'ComposeOptions', data: Record<string, unknown>): void;
