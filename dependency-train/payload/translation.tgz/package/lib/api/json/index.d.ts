import type { JSONSchema7 } from 'json-schema';
import type { JSONObject } from 'src/json';
import type { ParseOptions, TemplateOptions } from 'src/xliff';
import type { SkeletonOptions } from 'src/skeleton';
import type { IdOptions } from 'src/hash';
type JSONSchema = JSONSchema7 & {
    $id: string;
};
type JSONSchemas = {
    schemas: JSONSchema[];
};
export type AjvOptions = {
    keywords?: string[];
    extendWithSchemas?: JSONSchema[];
};
export type AjvConfig = {
    ajvOptions?: AjvOptions;
};
export type ExtractOptions = JSONSchemas & TemplateOptions & SkeletonOptions & AjvConfig & IdOptions;
export type ExtractOutput = {
    skeleton: JSONObject;
    xliff: string;
    units: string[];
};
export type ComposeOptions = JSONSchemas & ParseOptions & AjvConfig;
export declare function extract(content: JSONObject, { schemas, source, target, compact, ajvOptions, unitLocalIds }: ExtractOptions): ExtractOutput;
export declare function compose(skeleton: JSONObject, xliff: string | string[], { useSource }: ComposeOptions): any;
export {};
