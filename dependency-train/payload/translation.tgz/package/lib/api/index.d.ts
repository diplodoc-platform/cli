import type { ComposeOptions as MdComposeOptions, ExtractOptions as MdExtractOptions } from './md';
import type { ComposeOptions as JsonComposeOptions, ExtractOptions as JsonExtractOptions } from './json';
import type { JSONObject } from 'src/json';
import type { ComposeOptions as MdExpComposeOptions, ComposeOutput as MdExpComposeOutput, ExtractOptions as MdExpExtractOptions, ExtractOutput as MdExpExtractOutput } from './mdExp';
import { compose as composeMd, extract as extraactMd } from './md';
import { compose as composeMdExp, extract as extractMdExp } from './mdExp';
import { compose as composeJson, extract as extraactJson } from './json';
export type { AjvOptions } from './json';
export type ExtractOptions = JsonExtractOptions | MdExtractOptions;
export type ExtractOutput<T extends string | JSONObject> = {
    skeleton: T;
    xliff: string;
    units: string[];
    /** Problems that left a part of the content untranslated, one line each. Markdown only. */
    warnings?: string[];
    /** Markdown units inside wide-table titles; absent for other formats. */
    tableTitles?: number[][];
};
export declare function extract(content: string, options: MdExpExtractOptions): MdExpExtractOutput;
export declare function extract(content: string, options: ExtractOptions): ExtractOutput<string>;
export declare function extract(content: JSONObject, options: JsonExtractOptions): ExtractOutput<JSONObject>;
export declare namespace extract {
    var mdExp: typeof extractMdExp;
    var md: typeof extraactMd;
    var json: typeof extraactJson;
}
export type ComposeOptions = JsonComposeOptions | MdComposeOptions;
export declare function compose(skeleton: string, xliff: string, options: MdExpComposeOptions): MdExpComposeOutput;
export declare function compose(skeleton: string, xliff: string | string[], options: ComposeOptions): string;
export declare function compose(skeleton: JSONObject, xliff: string | string[], options: JsonComposeOptions): JSONObject;
export declare namespace compose {
    var mdExp: typeof composeMdExp;
    var md: typeof composeMd;
    var json: typeof composeJson;
}
