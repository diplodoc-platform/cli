import type { TemplateOptions } from 'src/xliff';
import type { SkeletonOptions } from 'src/skeleton';
import type { IdOptions } from 'src/hash';
export type ExtractOptions = TemplateOptions & SkeletonOptions & IdOptions;
export type ExtractOutput = {
    skeleton: string;
    xliff: string;
    units: string[];
    /** Problems that left a part of the content untranslated, one line each. */
    warnings: string[];
    /** Units inside wide-table titles, requiring attribute-safe translations. */
    tableTitles?: number[][];
};
export type ComposeOptions = {
    useSource?: boolean;
};
export declare function extract(content: string, options: ExtractOptions): ExtractOutput;
export declare function compose(skeleton: string, xliff: string | string[], { useSource }: {
    useSource?: boolean | undefined;
}): string;
