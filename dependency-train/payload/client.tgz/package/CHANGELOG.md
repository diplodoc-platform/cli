# Changelog

## [5.14.10](https://github.com/diplodoc-platform/client/compare/v5.14.9...v5.14.10) (2026-11-10)


### Bug Fixes

* **search:** preserve results page path during pagination ([ffc9815](https://github.com/diplodoc-platform/client/commit/ffc9815cb500fbf0c744818d8d95f23e27c24482))

## [5.14.9](https://github.com/diplodoc-platform/client/compare/v5.14.8...v5.14.9) (2026-10-28)


### Bug Fixes

* **deps:** Update dev:@diplodoc/transform@4.78.11 ([5b18ce0](https://github.com/diplodoc-platform/client/commit/5b18ce0a0d90924232cd794265864c86f3454cbb))
* derive navigation types from component contracts ([24563ed](https://github.com/diplodoc-platform/client/commit/24563ed4df6c6aa19df5508fd62afcba24ef79a3))
* preserve constructor styles in the shared runtime ([db7d41b](https://github.com/diplodoc-platform/client/commit/db7d41b1ab8db599c1e57ab21c17b7bdbad508a7))
* share the components navigation runtime context ([32108ce](https://github.com/diplodoc-platform/client/commit/32108ce80b1df2d5d2ccf698ce6f6a9af33d12fb))

## [5.14.8](https://github.com/diplodoc-platform/client/compare/v5.14.7...v5.14.8) (2026-10-10)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.24.1 ([97afe50](https://github.com/diplodoc-platform/client/commit/97afe501e1882569c4d759ce92b43d4e91801666))

## [5.14.7](https://github.com/diplodoc-platform/client/compare/v5.14.6...v5.14.7) (2026-10-02)


### Bug Fixes

* **deps:** Update dev:@diplodoc/openapi-extension@5.2.7 ([#476](https://github.com/diplodoc-platform/client/issues/476)) ([d2dbb42](https://github.com/diplodoc-platform/client/commit/d2dbb4269f09c14d0b73c74534469880a8f8a24d))

## [5.14.6](https://github.com/diplodoc-platform/client/compare/v5.14.5...v5.14.6) (2026-09-30)


### Bug Fixes

* **deps:** Update dev:@diplodoc/transform@4.78.3 ([#474](https://github.com/diplodoc-platform/client/issues/474)) ([4bbaba3](https://github.com/diplodoc-platform/client/commit/4bbaba3222b3868fcabdb89da5ebb531ccf703e7))

## [5.14.5](https://github.com/diplodoc-platform/client/compare/v5.14.4...v5.14.5) (2026-09-30)


### Bug Fixes

* **deps:** Update dev:@diplodoc/transform@4.78.2, dev:@diplodoc/openapi-extension@5.2.6 ([#472](https://github.com/diplodoc-platform/client/issues/472)) ([cca822b](https://github.com/diplodoc-platform/client/commit/cca822b208edfddfe15e1a4274232cc92d07e125))

## [5.14.4](https://github.com/diplodoc-platform/client/compare/v5.14.3...v5.14.4) (2026-09-30)


### Bug Fixes

* **deps:** Update dev:@diplodoc/transform@4.78.2, @diplodoc/openapi-extension@5.2.5 ([#469](https://github.com/diplodoc-platform/client/issues/469)) ([c2da79e](https://github.com/diplodoc-platform/client/commit/c2da79e7bf7c218978c5dc9bce404adf113c0250))

## [5.14.3](https://github.com/diplodoc-platform/client/compare/v5.14.2...v5.14.3) (2026-09-25)


### Bug Fixes

* restore static HTML from rendered page ([161e128](https://github.com/diplodoc-platform/client/commit/161e128df1ad62e2865696e3546a567f9dff7483))

## [5.14.2](https://github.com/diplodoc-platform/client/compare/v5.14.1...v5.14.2) (2026-09-25)


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.24.0 ([#466](https://github.com/diplodoc-platform/client/issues/466)) ([cfb5778](https://github.com/diplodoc-platform/client/commit/cfb5778f2335bcb014f2d44c9755f5a4e5076527))

## [5.14.1](https://github.com/diplodoc-platform/client/compare/v5.14.0...v5.14.1) (2026-09-22)


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.23.2 ([ae787ed](https://github.com/diplodoc-platform/client/commit/ae787ed857a644fa67992ebbeaf8c968ed553b92))

## [5.14.0](https://github.com/diplodoc-platform/client/compare/v5.13.2...v5.14.0) (2026-09-17)


### Features

* accept Markdown actions interface mode ([5551f5f](https://github.com/diplodoc-platform/client/commit/5551f5f5f7e22f1075521c760a5f2f34461258c9))

## [5.13.2](https://github.com/diplodoc-platform/client/compare/v5.13.1...v5.13.2) (2026-09-15)


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.22.0 ([#458](https://github.com/diplodoc-platform/client/issues/458)) ([07ff11f](https://github.com/diplodoc-platform/client/commit/07ff11fdc353f5f1d1fb14bf81a55ae614c45c6a))

## [5.13.1](https://github.com/diplodoc-platform/client/compare/v5.13.0...v5.13.1) (2026-09-14)


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.21.0 ([451b1c8](https://github.com/diplodoc-platform/client/commit/451b1c8db3cb96720c87f17f5d844dfaab3ad58f))

## [5.13.0](https://github.com/diplodoc-platform/client/compare/v5.12.2...v5.13.0) (2026-09-14)


### Features

* update @gravity-ui/page-constructor to 8.21.1 ([#451](https://github.com/diplodoc-platform/client/issues/451)) ([2a3cfdf](https://github.com/diplodoc-platform/client/commit/2a3cfdf6ad190e99863e3330757c0bf513c87894))

## [5.12.2](https://github.com/diplodoc-platform/client/compare/v5.12.1...v5.12.2) (2026-09-10)


### Bug Fixes

* wire search tag result counts ([#452](https://github.com/diplodoc-platform/client/issues/452)) ([bd82378](https://github.com/diplodoc-platform/client/commit/bd823788d54f82e04f5ade6cd0b4dc54f273442a))

## [5.12.1](https://github.com/diplodoc-platform/client/compare/v5.12.0...v5.12.1) (2026-09-07)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.20.1 ([#449](https://github.com/diplodoc-platform/client/issues/449)) ([ecaf470](https://github.com/diplodoc-platform/client/commit/ecaf470a960312ef93dc3bf90d0797f371451f08))

## [5.12.0](https://github.com/diplodoc-platform/client/compare/v5.11.11...v5.12.0) (2026-09-07)


### Features

* add back to top button ([#447](https://github.com/diplodoc-platform/client/issues/447)) ([a035ca2](https://github.com/diplodoc-platform/client/commit/a035ca27b5fe3b41203e1fee07f564ac37142e0c))


### Bug Fixes

* **deps:** Update @diplodoc/tabs-extension@3.10.7 ([#442](https://github.com/diplodoc-platform/client/issues/442)) ([65be4ad](https://github.com/diplodoc-platform/client/commit/65be4ad6b1f1f96f6a1a949bce6adbabfa3f66a9))

## [5.11.11](https://github.com/diplodoc-platform/client/compare/v5.11.10...v5.11.11) (2026-08-27)


### Bug Fixes

* **deps:** Update dev:@diplodoc/transform@4.77.15 ([c8dfdbe](https://github.com/diplodoc-platform/client/commit/c8dfdbe155a64cdb7128fe2491951c45ab60a566))

## [5.11.10](https://github.com/diplodoc-platform/client/compare/v5.11.9...v5.11.10) (2026-08-26)


### Bug Fixes

* **deps:** Update dev:@diplodoc/page-constructor-extension@0.13.13 ([636427d](https://github.com/diplodoc-platform/client/commit/636427d7e7ca53f2a396ab17f122411ec1391db1))

## [5.11.9](https://github.com/diplodoc-platform/client/compare/v5.11.8...v5.11.9) (2026-08-20)


### Bug Fixes

* **deps:** Update dev:@diplodoc/mermaid-extension@2.2.3 ([f4270d9](https://github.com/diplodoc-platform/client/commit/f4270d9f9df985bd424f8d842f58f21419089798))

## [5.11.8](https://github.com/diplodoc-platform/client/compare/v5.11.7...v5.11.8) (2026-08-14)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.18.7 ([27732b0](https://github.com/diplodoc-platform/client/commit/27732b011cf593952526bff3bb9d523ab2a8e834))

## [5.11.7](https://github.com/diplodoc-platform/client/compare/v5.11.6...v5.11.7) (2026-08-14)


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.18.6 ([#430](https://github.com/diplodoc-platform/client/issues/430)) ([5da95a5](https://github.com/diplodoc-platform/client/commit/5da95a59156b747433e06ca438c978764ada7691))

## [5.11.6](https://github.com/diplodoc-platform/client/compare/v5.11.5...v5.11.6) (2026-08-13)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.18.5 ([8fdc9ec](https://github.com/diplodoc-platform/client/commit/8fdc9eccda4e88c626e75f2260152ab7fd3add94))

## [5.11.5](https://github.com/diplodoc-platform/client/compare/v5.11.4...v5.11.5) (2026-08-13)


### Bug Fixes

* fixed tags ([#426](https://github.com/diplodoc-platform/client/issues/426)) ([74913a1](https://github.com/diplodoc-platform/client/commit/74913a17809a57eb2dc02540b9514df48c1ad2d7))

## [5.11.4](https://github.com/diplodoc-platform/client/compare/v5.11.3...v5.11.4) (2026-08-12)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.18.4 ([fe0fe04](https://github.com/diplodoc-platform/client/commit/fe0fe04bb0024c17c0c7ac7efc11fbf372d7ed7e))

## [5.11.3](https://github.com/diplodoc-platform/client/compare/v5.11.2...v5.11.3) (2026-08-10)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.18.3 ([0cba285](https://github.com/diplodoc-platform/client/commit/0cba28523218b763565b148c3d8c6ec56dec8424))

## [5.11.2](https://github.com/diplodoc-platform/client/compare/v5.11.1...v5.11.2) (2026-08-07)


### Bug Fixes

* Upgrade typescript to 5.9.3 DOCSTOOLS-6357 ([d11bc92](https://github.com/diplodoc-platform/client/commit/d11bc92c13cc24f128c91551aab696c9a70a4be2))
* Upgrade typescript to 6.0.3 DOCSTOOLS-6359 ([f16409c](https://github.com/diplodoc-platform/client/commit/f16409c2b46a150e140dfc06b8e3afaf65cb4588))

## [5.11.1](https://github.com/diplodoc-platform/client/compare/v5.11.0...v5.11.1) (2026-08-06)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.18.1 ([4053b48](https://github.com/diplodoc-platform/client/commit/4053b48e7729d1d9efd0e347f54b4b05f8ad415d))

## [5.11.0](https://github.com/diplodoc-platform/client/compare/v5.10.3...v5.11.0) (2026-08-06)


### Features

* added page tags ([#417](https://github.com/diplodoc-platform/client/issues/417)) ([282d250](https://github.com/diplodoc-platform/client/commit/282d25003759e50b6465362c10a5d17b0974bd74))


### Bug Fixes

* **deps:** Update @diplodoc/components@5.17.5 ([dd84f0e](https://github.com/diplodoc-platform/client/commit/dd84f0e3dc45787f2a1a1c1c66fd9859d052c427))
* **deps:** Update @diplodoc/components@5.17.6 ([cd478f3](https://github.com/diplodoc-platform/client/commit/cd478f3d86dcf881ab1a943b1d7ed80b87b6545b))

## [5.10.3](https://github.com/diplodoc-platform/client/compare/v5.10.2...v5.10.3) (2026-08-04)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.17.4 ([6735203](https://github.com/diplodoc-platform/client/commit/673520312998d647b610330cc125fd0ce2acb619))

## [5.10.2](https://github.com/diplodoc-platform/client/compare/v5.10.1...v5.10.2) (2026-07-29)


### Bug Fixes

* **deps:** Update dev:@diplodoc/transform@4.77.8 ([#408](https://github.com/diplodoc-platform/client/issues/408)) ([fd19c7b](https://github.com/diplodoc-platform/client/commit/fd19c7b5bc8d8ad31c30b66d87df1e1156596f18))

## [5.10.1](https://github.com/diplodoc-platform/client/compare/v5.10.0...v5.10.1) (2026-07-28)


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.17.3, dev:@diplodoc/tabs-extension@3.10.5, dev:@diplodoc/transform@4.77.7 ([#406](https://github.com/diplodoc-platform/client/issues/406)) ([bdd25e1](https://github.com/diplodoc-platform/client/commit/bdd25e14263a3e4d9116e4db01b2bc794df8e76c))
* missing JSX.Element in react-compat shim ([#402](https://github.com/diplodoc-platform/client/issues/402)) ([3853780](https://github.com/diplodoc-platform/client/commit/3853780d058b49e07872ef915b9bb73179cfd903))

## [5.10.0](https://github.com/diplodoc-platform/client/compare/v5.9.3...v5.10.0) (2026-07-27)


### Features

* update react version ([#400](https://github.com/diplodoc-platform/client/issues/400)) ([a525f28](https://github.com/diplodoc-platform/client/commit/a525f28e38fbbd933501edc0e59da8e5ce095868))


### Bug Fixes

* changed cursor to zoom-in for img and svg ([64fcbda](https://github.com/diplodoc-platform/client/commit/64fcbdaf73c134e6daafc9b9bcd01bf0c3255c59))
* **deps:** Update @diplodoc/components@5.16.3 ([a41677a](https://github.com/diplodoc-platform/client/commit/a41677a4b506c6dbfb7673fc4c718122414e749b))

## [5.9.3](https://github.com/diplodoc-platform/client/compare/v5.9.2...v5.9.3) (2026-07-23)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.16.2 ([c961606](https://github.com/diplodoc-platform/client/commit/c9616065560c768dff87b4db6f8bd3c6c40993c2))

## [5.9.2](https://github.com/diplodoc-platform/client/compare/v5.9.1...v5.9.2) (2026-07-20)


### Bug Fixes

* **deps:** Update @diplodoc/transform@4.77.1 ([b4717c8](https://github.com/diplodoc-platform/client/commit/b4717c8ba9073acf2f9ae90c39666ea3a82b7c9c))

## [5.9.1](https://github.com/diplodoc-platform/client/compare/v5.9.0...v5.9.1) (2026-07-20)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.16.1 ([#385](https://github.com/diplodoc-platform/client/issues/385)) ([3cbc3da](https://github.com/diplodoc-platform/client/commit/3cbc3da774b58fc5e38462bc896147dd1cf1695d))
* **deps:** Update @diplodoc/page-constructor-extension@0.13.8 ([#388](https://github.com/diplodoc-platform/client/issues/388)) ([08db4fc](https://github.com/diplodoc-platform/client/commit/08db4fccb8376b0747b402816f801235d16b58fc))

## [5.9.0](https://github.com/diplodoc-platform/client/compare/v5.8.1...v5.9.0) (2026-07-14)


### Features

* added footer ([#383](https://github.com/diplodoc-platform/client/issues/383)) ([8c524e4](https://github.com/diplodoc-platform/client/commit/8c524e4e7efe33295068840593dd87a69aa7add3))

## [5.8.1](https://github.com/diplodoc-platform/client/compare/v5.8.0...v5.8.1) (2026-07-14)


### Bug Fixes

* add cursor pointer to gallery images ([3c0707d](https://github.com/diplodoc-platform/client/commit/3c0707de18ff2e35f61c161e74cf15574b818e5a))
* **deps:** Update dev:@diplodoc/mermaid-extension@2.2.0 ([#382](https://github.com/diplodoc-platform/client/issues/382)) ([8ec91b4](https://github.com/diplodoc-platform/client/commit/8ec91b49cee59dc2f4ccb069f5c3e3db308ea0cf))

## [5.8.0](https://github.com/diplodoc-platform/client/compare/v5.7.14...v5.8.0) (2026-07-06)


### Features

* tabs expand if the anchor leads to content inside ([#377](https://github.com/diplodoc-platform/client/issues/377)) ([7e2c477](https://github.com/diplodoc-platform/client/commit/7e2c4773b07c5234c8489b96caed9d90035d03ae))

## [5.7.14](https://github.com/diplodoc-platform/client/compare/v5.7.13...v5.7.14) (2026-06-24)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.12.2 ([7ef2a56](https://github.com/diplodoc-platform/client/commit/7ef2a56f21730476e28b6ad4f77861af6f1874c9))

## [5.7.13](https://github.com/diplodoc-platform/client/compare/v5.7.12...v5.7.13) (2026-06-19)


### Bug Fixes

* add Gallery ([b7f1d2b](https://github.com/diplodoc-platform/client/commit/b7f1d2bdebaf41c22b42133657965b1245e3cc7c))
* **deps:** Update dev:@diplodoc/components@5.11.0 ([#368](https://github.com/diplodoc-platform/client/issues/368)) ([c15d312](https://github.com/diplodoc-platform/client/commit/c15d3127917a7fadb936fe27ffbed6a65ae2c8ea))

## [5.7.12](https://github.com/diplodoc-platform/client/compare/v5.7.11...v5.7.12) (2026-06-19)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.10.3 ([8c8ce0a](https://github.com/diplodoc-platform/client/commit/8c8ce0ab4a7603163d067eecceb500f65351e2b2))

## [5.7.11](https://github.com/diplodoc-platform/client/compare/v5.7.10...v5.7.11) (2026-06-19)


### Bug Fixes

* **deps:** Update dev:@diplodoc/openapi-extension@5.2.1 ([010bb04](https://github.com/diplodoc-platform/client/commit/010bb04032b9392df07ba826ee81d90caea1bec9))

## [5.7.10](https://github.com/diplodoc-platform/client/compare/v5.7.9...v5.7.10) (2026-06-19)


### Bug Fixes

* **deps:** Update dev:@diplodoc/openapi-extension@5.2.0 ([dd5b8f9](https://github.com/diplodoc-platform/client/commit/dd5b8f9deb8509660b58b82ba605527f2a2d2ca4))

## [5.7.9](https://github.com/diplodoc-platform/client/compare/v5.7.8...v5.7.9) (2026-06-10)


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.10.2 ([#357](https://github.com/diplodoc-platform/client/issues/357)) ([7f2ebb0](https://github.com/diplodoc-platform/client/commit/7f2ebb045c1ae20be27768f8bc9a833e7f1e0a97))

## [5.7.8](https://github.com/diplodoc-platform/client/compare/v5.7.7...v5.7.8) (2026-06-10)


### Bug Fixes

* **deps:** Update dev:@diplodoc/mermaid-extension@2.1.2 ([338f29e](https://github.com/diplodoc-platform/client/commit/338f29ed1d76c6cd8af507baabe1dd4ff521c81e))

## [5.7.7](https://github.com/diplodoc-platform/client/compare/v5.7.6...v5.7.7) (2026-06-01)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.9.5 ([cb726fe](https://github.com/diplodoc-platform/client/commit/cb726fe8a6b697e70565e77f02d88b1ab112a823))

## [5.7.6](https://github.com/diplodoc-platform/client/compare/v5.7.5...v5.7.6) (2026-05-29)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.9.4 ([#347](https://github.com/diplodoc-platform/client/issues/347)) ([0bbe141](https://github.com/diplodoc-platform/client/commit/0bbe141518c2b92f7b386ffb503b40d1cd307921))

## [5.7.5](https://github.com/diplodoc-platform/client/compare/v5.7.4...v5.7.5) (2026-05-28)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.9.3 ([#345](https://github.com/diplodoc-platform/client/issues/345)) ([5026773](https://github.com/diplodoc-platform/client/commit/5026773caf3750f7ae7fbceb2c6f749d514664eb))

## [5.7.4](https://github.com/diplodoc-platform/client/compare/v5.7.3...v5.7.4) (2026-05-28)


### Bug Fixes

* **deps:** updated node to 24 ([#342](https://github.com/diplodoc-platform/client/issues/342)) ([7da41c1](https://github.com/diplodoc-platform/client/commit/7da41c10f36587fd10bb846166be7fdd9cb8d065))

## [5.7.3](https://github.com/diplodoc-platform/client/compare/v5.7.2...v5.7.3) (2026-05-27)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.9.2 ([#339](https://github.com/diplodoc-platform/client/issues/339)) ([5712906](https://github.com/diplodoc-platform/client/commit/571290623b7bae5989921063727748d58d92854b))
* **deps:** Update @diplodoc/page-constructor-extension@0.13.4 ([#337](https://github.com/diplodoc-platform/client/issues/337)) ([5d988f1](https://github.com/diplodoc-platform/client/commit/5d988f1c07f873c480488efe2bcfd6a9dd4721f7))
* updated pc ([#340](https://github.com/diplodoc-platform/client/issues/340)) ([cb34a66](https://github.com/diplodoc-platform/client/commit/cb34a66aa7db85f4733b58218cc0b2b7f9cb08c6))

## [5.7.2](https://github.com/diplodoc-platform/client/compare/v5.7.1...v5.7.2) (2026-05-25)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.9.1 ([b32c678](https://github.com/diplodoc-platform/client/commit/b32c6780c00a289c46bdc481a974730a64f68be8))

## [5.7.1](https://github.com/diplodoc-platform/client/compare/v5.7.0...v5.7.1) (2026-05-20)


### Bug Fixes

* disable elastic scroll behavior ([#331](https://github.com/diplodoc-platform/client/issues/331)) ([bf9b05b](https://github.com/diplodoc-platform/client/commit/bf9b05b10eeb89de77dabc8cf91d317fff72dea4))

## [5.7.0](https://github.com/diplodoc-platform/client/compare/v5.6.1...v5.7.0) (2026-05-18)


### Features

* use custom dropdown to support multi columns ([#329](https://github.com/diplodoc-platform/client/issues/329)) ([31a345d](https://github.com/diplodoc-platform/client/commit/31a345d36ce88f3a9fc23dc179659c1d509dfe0a))

## [5.6.1](https://github.com/diplodoc-platform/client/compare/v5.6.0...v5.6.1) (2026-05-14)


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.9.0 ([#324](https://github.com/diplodoc-platform/client/issues/324)) ([c671569](https://github.com/diplodoc-platform/client/commit/c671569fc42a2520d64c52ee3c41e0f541f76574))

## [5.6.0](https://github.com/diplodoc-platform/client/compare/v5.5.4...v5.6.0) (2026-05-08)


### Features

* add analytics to page constructor provider ([#301](https://github.com/diplodoc-platform/client/issues/301)) ([9829317](https://github.com/diplodoc-platform/client/commit/9829317312fbbfccbf64e8e20df8973348c98769))

## [5.5.4](https://github.com/diplodoc-platform/client/compare/v5.5.3...v5.5.4) (2026-05-01)


### Bug Fixes

* **deps:** Update @diplodoc/components@5.7.3 ([#321](https://github.com/diplodoc-platform/client/issues/321)) ([838c72e](https://github.com/diplodoc-platform/client/commit/838c72e88ed77fb1db1fb4f88faa90bbc8e7c811))

## [5.5.3](https://github.com/diplodoc-platform/client/compare/v5.5.2...v5.5.3) (2026-04-29)


### Bug Fixes

* **deps:** Update dev:@diplodoc/transform@4.74.0 ([3457e87](https://github.com/diplodoc-platform/client/commit/3457e873e9bfbf12ffdfdd83435a265bf0b7dd8b))

## [5.5.2](https://github.com/diplodoc-platform/client/compare/v5.5.1...v5.5.2) (2026-04-23)


### Bug Fixes

* **deps:** Update @diplodoc/components to 5.7.2 ([8d64c4f](https://github.com/diplodoc-platform/client/commit/8d64c4fecc60978849bd296209dd6b252c3002d8))

## [5.5.1](https://github.com/diplodoc-platform/client/compare/v5.5.0...v5.5.1) (2026-04-21)


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.7.1 ([#314](https://github.com/diplodoc-platform/client/issues/314)) ([3cca668](https://github.com/diplodoc-platform/client/commit/3cca6680823c1f25005b1e79b3f1149e543d726a))

## [5.5.0](https://github.com/diplodoc-platform/client/compare/v5.4.1...v5.5.0) (2026-04-17)


### Features

* added neuroExpert in search ([#307](https://github.com/diplodoc-platform/client/issues/307)) ([e1ee5c2](https://github.com/diplodoc-platform/client/commit/e1ee5c2e95ad293523e27c08f0c8ebd07ff0c578))

## [5.4.1](https://github.com/diplodoc-platform/client/compare/v5.4.0...v5.4.1) (2026-04-17)


### Bug Fixes

* set correct gap for navigation buttons ([#309](https://github.com/diplodoc-platform/client/issues/309)) ([49a3282](https://github.com/diplodoc-platform/client/commit/49a3282ca074c7580c84a7b3d9643cf5c14c5fc1))

## [5.4.0](https://github.com/diplodoc-platform/client/compare/v5.3.1...v5.4.0) (2026-04-17)


### Features

* add support label in header ([22f6c32](https://github.com/diplodoc-platform/client/commit/22f6c32067be1fb4d6a7858be6435d692790cef2))


### Bug Fixes

* forward theme prop to page constructor runtime ([#302](https://github.com/diplodoc-platform/client/issues/302)) ([aad3d00](https://github.com/diplodoc-platform/client/commit/aad3d00c0528d9967c5743cd2df1444774b0dcf9))
* update type for search result data ([7c0835a](https://github.com/diplodoc-platform/client/commit/7c0835abbbb3e1e207463300b4ce6363867dfe76))

## [5.3.1](https://github.com/diplodoc-platform/client/compare/v5.3.0...v5.3.1) (2026-04-10)


### Bug Fixes

* set correct type for app component ([#299](https://github.com/diplodoc-platform/client/issues/299)) ([1683446](https://github.com/diplodoc-platform/client/commit/1683446e5033de8f7d177032f2dff31a2e45e036))

## [5.3.0](https://github.com/diplodoc-platform/client/compare/v5.2.17...v5.3.0) (2026-04-10)


### Features

* **analytics:** setup analytics service ([#292](https://github.com/diplodoc-platform/client/issues/292)) ([68ed060](https://github.com/diplodoc-platform/client/commit/68ed0605f9416037d669effff341b2bc9b5e4d5d))


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.4.0 ([#297](https://github.com/diplodoc-platform/client/issues/297)) ([f10f61a](https://github.com/diplodoc-platform/client/commit/f10f61aff2951d53ecb749a15084b90b3fe4eb71))

## [5.2.17](https://github.com/diplodoc-platform/client/compare/v5.2.16...v5.2.17) (2026-04-08)


### Bug Fixes

* fixed release ([#295](https://github.com/diplodoc-platform/client/issues/295)) ([9d72fcb](https://github.com/diplodoc-platform/client/commit/9d72fcb65f4c306bfbd7f9567728750d287859e5))

## [5.2.16](https://github.com/diplodoc-platform/client/compare/v5.2.15...v5.2.16) (2026-04-08)


### Bug Fixes

* neuroexpert widget has been made adaptive ([#293](https://github.com/diplodoc-platform/client/issues/293)) ([49190ff](https://github.com/diplodoc-platform/client/commit/49190ff60bdab952d27f8ea40485a3ad2fe651ae))

## [5.2.15](https://github.com/diplodoc-platform/client/compare/v5.2.14...v5.2.15) (2026-04-07)


### Bug Fixes

* added dark theme to neuro expert button ([f79f8e9](https://github.com/diplodoc-platform/client/commit/f79f8e9de8a2bfd3a8a55bfe8426bb5dbc89662d))

## [5.2.14](https://github.com/diplodoc-platform/client/compare/v5.2.13...v5.2.14) (2026-04-02)


### Bug Fixes

* **deps:** Update dev:@diplodoc/transform@4.73.1, dev:@diplodoc/components@5.3.2 ([#288](https://github.com/diplodoc-platform/client/issues/288)) ([7a5362a](https://github.com/diplodoc-platform/client/commit/7a5362a525d11db3517df853952279bed31e3876))
* prevent custom controls unmounting on settings change ([#279](https://github.com/diplodoc-platform/client/issues/279)) ([95b3cef](https://github.com/diplodoc-platform/client/commit/95b3cef88c99057e389d9632cb4a696df25c4ba1))

## [5.2.13](https://github.com/diplodoc-platform/client/compare/v5.2.12...v5.2.13) (2026-04-01)


### Bug Fixes

* **deps:** Update @diplodoc/components to 5.3.1 ([#285](https://github.com/diplodoc-platform/client/issues/285)) ([4e7f1c1](https://github.com/diplodoc-platform/client/commit/4e7f1c168eaaf4e01984d0d7fa1ae6393a3a434a))

## [5.2.12](https://github.com/diplodoc-platform/client/compare/v5.2.11...v5.2.12) (2026-03-27)


### Bug Fixes

* **deps:** Update dev:@diplodoc/components@5.3.0 ([#282](https://github.com/diplodoc-platform/client/issues/282)) ([3ad54a0](https://github.com/diplodoc-platform/client/commit/3ad54a0c50b9c8ef306bf7e6d0eb9d3d0064ea97))

## [5.2.11](https://github.com/diplodoc-platform/client/compare/v5.2.10...v5.2.11) (2026-03-20)


### Bug Fixes

* **deps:** Update dev:@diplodoc/transform@4.71.0 ([#275](https://github.com/diplodoc-platform/client/issues/275)) ([f9defbf](https://github.com/diplodoc-platform/client/commit/f9defbf0a2e664a248b8e23be6ea70f9de187686))

## [5.2.10](https://github.com/diplodoc-platform/client/compare/v5.2.9...v5.2.10) (2026-03-18)


### Bug Fixes

* **deps:** Update transform@4.70.4 ([b55e36c](https://github.com/diplodoc-platform/client/commit/b55e36c35cc5e734c60cdce0d2dcc40982f977ad))

## [5.2.9](https://github.com/diplodoc-platform/client/compare/v5.2.8...v5.2.9) (2026-03-17)


### Bug Fixes

* **deps:** Update @diplodoc/page-constructor-extension to 0.13.2 ([#268](https://github.com/diplodoc-platform/client/issues/268)) ([09459a1](https://github.com/diplodoc-platform/client/commit/09459a18636d0a3f4a18e611da445376657d8e14))
* **deps:** update transform ([901f6f7](https://github.com/diplodoc-platform/client/commit/901f6f7ae6a643abc80ca1dee8f8be4035112184))
* table wide not worked ([3db1a0c](https://github.com/diplodoc-platform/client/commit/3db1a0c868ace859ba87ec88ac2a256b2666831c))

## [5.2.8](https://github.com/diplodoc-platform/client/compare/v5.2.7...v5.2.8) (2026-03-10)


### Bug Fixes

* update uikit to a bug-free version ([#264](https://github.com/diplodoc-platform/client/issues/264)) ([2c44415](https://github.com/diplodoc-platform/client/commit/2c444151fb1e589b43f0d8e15f49a76ae9dd0dae))

## [5.2.7](https://github.com/diplodoc-platform/client/compare/v5.2.6...v5.2.7) (2026-03-05)


### Bug Fixes

* fixed unmount pages after changing settings ([dfabbb2](https://github.com/diplodoc-platform/client/commit/dfabbb2b4799905e5db8a613de48de3299fb059b))

## [5.2.6](https://github.com/diplodoc-platform/client/compare/v5.2.5...v5.2.6) (2026-03-02)


### Bug Fixes

* **deps:** Update @diplodoc/components to 5.2.6 ([#259](https://github.com/diplodoc-platform/client/issues/259)) ([a8021d8](https://github.com/diplodoc-platform/client/commit/a8021d8dba4375648fe6cc102788c7498a7efd2d))

## [5.2.5](https://github.com/diplodoc-platform/client/compare/v5.2.4...v5.2.5) (2026-02-27)


### Bug Fixes

* fixed search bar ([#256](https://github.com/diplodoc-platform/client/issues/256)) ([e30f233](https://github.com/diplodoc-platform/client/commit/e30f2332ab9aa8b0539e53e80a77efcdeaad9e80))

## [5.2.4](https://github.com/diplodoc-platform/client/compare/v5.2.3...v5.2.4) (2026-02-27)


### Bug Fixes

* **deps:** Update @diplodoc/components to 5.2.5 ([#254](https://github.com/diplodoc-platform/client/issues/254)) ([ad0fcc6](https://github.com/diplodoc-platform/client/commit/ad0fcc624caf210b62fbd64e2fdb5e20d6c27ace))

## [5.2.3](https://github.com/diplodoc-platform/client/compare/v5.2.2...v5.2.3) (2026-02-26)


### Bug Fixes

* **deps:** Update @diplodoc/components to 5.2.4 ([#253](https://github.com/diplodoc-platform/client/issues/253)) ([b27a896](https://github.com/diplodoc-platform/client/commit/b27a896e39ad9c07d66573b08b05f5a7805af3e1))
* Update infra to v1.13.2 ([6cabb6a](https://github.com/diplodoc-platform/client/commit/6cabb6a368f53c94237c53f589e59066c6f073cf))

## [5.2.2](https://github.com/diplodoc-platform/client/compare/v5.2.1...v5.2.2) (2026-02-02)


### Bug Fixes

* **client:** use sass instead of sass-embedded in sass-loader ([e3cb86a](https://github.com/diplodoc-platform/client/commit/e3cb86a6e837bec2ce4549c49423dba01bc39ced))
* **deps:** Update @diplodoc/components to 5.2.2 ([#245](https://github.com/diplodoc-platform/client/issues/245)) ([1b8971e](https://github.com/diplodoc-platform/client/commit/1b8971ec9633791a7496a5ccecf4ceeb0e67119a))
* **deps:** Update @diplodoc/transform to 4.68.1 ([#242](https://github.com/diplodoc-platform/client/issues/242)) ([bd7dcc8](https://github.com/diplodoc-platform/client/commit/bd7dcc8bd108bc2ef6018c47f1a89a7eb2fcb3f0))
* Fix package releases ([f043ee1](https://github.com/diplodoc-platform/client/commit/f043ee1f5273171d86c9fdaa96bfb45e66aff05c))


### Performance Improvements

* **client:** enable modern-compiler API in sass-loader ([b7b3468](https://github.com/diplodoc-platform/client/commit/b7b3468558078195c64a7a13a8bfcd3d69c03b28))

## [5.2.1](https://github.com/diplodoc-platform/client/compare/v5.2.0...v5.2.1) (2026-02-02)


### Bug Fixes

* **client:** use sass instead of sass-embedded in sass-loader ([e3cb86a](https://github.com/diplodoc-platform/client/commit/e3cb86a6e837bec2ce4549c49423dba01bc39ced))
* **deps:** Update @diplodoc/transform to 4.68.1 ([#242](https://github.com/diplodoc-platform/client/issues/242)) ([bd7dcc8](https://github.com/diplodoc-platform/client/commit/bd7dcc8bd108bc2ef6018c47f1a89a7eb2fcb3f0))


### Performance Improvements

* **client:** enable modern-compiler API in sass-loader ([b7b3468](https://github.com/diplodoc-platform/client/commit/b7b3468558078195c64a7a13a8bfcd3d69c03b28))

## [5.2.1](https://github.com/diplodoc-platform/client/compare/v5.2.0...v5.2.1) (2026-01-27)


### Dependency update

* Update @diplodoc/components to 5.2.1 ([#238](https://github.com/diplodoc-platform/client/issues/238)) ([201ae11](https://github.com/diplodoc-platform/client/commit/201ae111ad4fb7a32b8f0d5cca193c2114946f84))

## [5.2.0](https://github.com/diplodoc-platform/client/compare/v5.1.1...v5.2.0) (2025-12-03)


### Features

* add feedback.url config option ([#233](https://github.com/diplodoc-platform/client/issues/233)) ([1682ad2](https://github.com/diplodoc-platform/client/commit/1682ad2f48c6b69975bebc98dc1a86b512c2c69c))

## [5.1.1](https://github.com/diplodoc-platform/client/compare/v5.1.0...v5.1.1) (2025-12-03)


### Dependency update

* Update openapi-extension ([1ea24cf](https://github.com/diplodoc-platform/client/commit/1ea24cf1e09ee3e294806c79fa128eceb8382570))

## [5.1.0](https://github.com/diplodoc-platform/client/compare/v5.0.0...v5.1.0) (2025-12-03)


### Features

* allow enable feedback ([#231](https://github.com/diplodoc-platform/client/issues/231)) ([54c8c9f](https://github.com/diplodoc-platform/client/commit/54c8c9fdaa3e8b89a18e5e380438ad35b6ff1c6d))

## [5.0.0](https://github.com/diplodoc-platform/client/compare/v4.2.0...v5.0.0) (2025-11-27)


### ⚠ BREAKING CHANGES

* updated @gravity-ui packages ([#228](https://github.com/diplodoc-platform/client/issues/228))

### Features

* updated [@gravity-ui](https://github.com/gravity-ui) packages ([#228](https://github.com/diplodoc-platform/client/issues/228)) ([689607e](https://github.com/diplodoc-platform/client/commit/689607eb5134d87ffcb93cb2fdd1115b0a6a2ab5))

## [4.2.0](https://github.com/diplodoc-platform/client/compare/v4.1.4...v4.2.0) (2025-11-19)


### Features

* added options to change the language ([#217](https://github.com/diplodoc-platform/client/issues/217)) ([2eb39f5](https://github.com/diplodoc-platform/client/commit/2eb39f5deca87b6daf04ec445cde8b724e3d463a))

## [4.1.4](https://github.com/diplodoc-platform/client/compare/v4.1.3...v4.1.4) (2025-11-19)


### Bug Fixes

* fixed npm version ([#224](https://github.com/diplodoc-platform/client/issues/224)) ([4a0abce](https://github.com/diplodoc-platform/client/commit/4a0abcee8d7255289897ccdf4eabb589059e9b63))

## [4.1.3](https://github.com/diplodoc-platform/client/compare/v4.1.2...v4.1.3) (2025-11-19)


### Bug Fixes

* fixed npm version ([#221](https://github.com/diplodoc-platform/client/issues/221)) ([5a0eb62](https://github.com/diplodoc-platform/client/commit/5a0eb62594bb8256466842d29fb4f3c84991a5a2))

## [4.1.2](https://github.com/diplodoc-platform/client/compare/v4.1.1...v4.1.2) (2025-11-05)


### Dependency update

* Update @diplodoc/components to 4.38.3 ([#214](https://github.com/diplodoc-platform/client/issues/214)) ([6007f23](https://github.com/diplodoc-platform/client/commit/6007f2306541e125658b274c3ce381926885e6a7))
* Update @diplodoc/components to 4.38.4 ([#216](https://github.com/diplodoc-platform/client/issues/216)) ([4d1ff99](https://github.com/diplodoc-platform/client/commit/4d1ff99a296b02677c1358072ab04106f9f080d6))

## [4.1.1](https://github.com/diplodoc-platform/client/compare/v4.1.0...v4.1.1) (2025-10-27)


### Bug Fixes

* fixed NeuroExpert logic ([#212](https://github.com/diplodoc-platform/client/issues/212)) ([8b9da10](https://github.com/diplodoc-platform/client/commit/8b9da10305ff27c7a5c1e332a9cde751eb5d4242))


### Dependency update

* Update @diplodoc/components to 4.38.1 ([#210](https://github.com/diplodoc-platform/client/issues/210)) ([a1afe86](https://github.com/diplodoc-platform/client/commit/a1afe86a325666d68f4498bf871501426b7db5f1))
* Update @diplodoc/components to 4.38.2 ([#213](https://github.com/diplodoc-platform/client/issues/213)) ([3308ece](https://github.com/diplodoc-platform/client/commit/3308ece49e403714e6c6dbcbec250e2343430543))

## [4.1.0](https://github.com/diplodoc-platform/client/compare/v4.0.2...v4.1.0) (2025-10-22)


### Features

* added neuro-expert ([#207](https://github.com/diplodoc-platform/client/issues/207)) ([b6fa2a9](https://github.com/diplodoc-platform/client/commit/b6fa2a969bb8c6ea9e4ab92c2b66d30c76a32f45))


### Dependency update

* Update @diplodoc/components to 4.38.0 ([#208](https://github.com/diplodoc-platform/client/issues/208)) ([5abfa80](https://github.com/diplodoc-platform/client/commit/5abfa801b0cdc595ba49718b6fb1d071201ec912))

## [4.0.2](https://github.com/diplodoc-platform/client/compare/v4.0.1...v4.0.2) (2025-10-17)


### Dependency update

* Update @diplodoc/components to 4.37.2 ([#205](https://github.com/diplodoc-platform/client/issues/205)) ([ddf9384](https://github.com/diplodoc-platform/client/commit/ddf9384f61618c0c73375959004787871f015384))

## [4.0.1](https://github.com/diplodoc-platform/client/compare/v4.0.0...v4.0.1) (2025-10-13)


### Bug Fixes

* fixed getLangPath ([#203](https://github.com/diplodoc-platform/client/issues/203)) ([e108823](https://github.com/diplodoc-platform/client/commit/e10882335e1f0d68748d7d6f436433641dd320fe))

## [4.0.0](https://github.com/diplodoc-platform/client/compare/v3.12.0...v4.0.0) (2025-09-30)


### ⚠ BREAKING CHANGES

* Remove legacy page  layout

### Features

* Remove legacy page  layout ([ab02c97](https://github.com/diplodoc-platform/client/commit/ab02c97027a26b509f3da87ed3b2861de09bc1cf))


### Dependency update

* Update @diplodoc/components to 4.36.0 ([#200](https://github.com/diplodoc-platform/client/issues/200)) ([917b9e0](https://github.com/diplodoc-platform/client/commit/917b9e0ef636f004bc97fb45673106fc8b77e19a))
* Update @diplodoc/components to 4.36.1 ([#201](https://github.com/diplodoc-platform/client/issues/201)) ([00c84a6](https://github.com/diplodoc-platform/client/commit/00c84a6f4166570fd4669e4a74e3f2ef837a5ba3))
* Update @diplodoc/components to 4.37.1 ([#202](https://github.com/diplodoc-platform/client/issues/202)) ([288fd56](https://github.com/diplodoc-platform/client/commit/288fd565d8a0bcac46c819a2a47b919e871f7a84))

## [3.12.0](https://github.com/diplodoc-platform/client/compare/v3.11.0...v3.12.0) (2025-09-18)


### Features

* added availableLangs ([#195](https://github.com/diplodoc-platform/client/issues/195)) ([7022cc3](https://github.com/diplodoc-platform/client/commit/7022cc39b06ce0fd70e074fdf94eef76d0e072dc))

## [3.11.0](https://github.com/diplodoc-platform/client/compare/v3.10.3...v3.11.0) (2025-09-05)


### Features

* adding theme provider in search page ([#191](https://github.com/diplodoc-platform/client/issues/191)) ([08486e7](https://github.com/diplodoc-platform/client/commit/08486e73c52dcd9cef1452cbdb8c339e1e890b17))


### Dependency update

* Update @diplodoc/components to 4.34.2 ([#197](https://github.com/diplodoc-platform/client/issues/197)) ([b80b972](https://github.com/diplodoc-platform/client/commit/b80b9725fdea91d999a3491a56e4593f3c1379bc))

## [3.10.3](https://github.com/diplodoc-platform/client/compare/v3.10.2...v3.10.3) (2025-08-29)


### Bug Fixes

* fixed useLangs and interceptors ([#189](https://github.com/diplodoc-platform/client/issues/189)) ([e88436e](https://github.com/diplodoc-platform/client/commit/e88436ed9f8347efa00f8d9f0650d1e29ca0d4ad))


### Dependency update

* Update @diplodoc/components to 4.34.1 ([#194](https://github.com/diplodoc-platform/client/issues/194)) ([f367e25](https://github.com/diplodoc-platform/client/commit/f367e2518a1bceb7f352aeb27fe4fe8b6f9f64c4))

## [3.10.2](https://github.com/diplodoc-platform/client/compare/v3.10.1...v3.10.2) (2025-08-28)


### Bug Fixes

* Fix cut hash navigation ([b23f4f1](https://github.com/diplodoc-platform/client/commit/b23f4f1ad0e8ceee7a5637f750d3ae395d33c672))

## [3.10.1](https://github.com/diplodoc-platform/client/compare/v3.10.0...v3.10.1) (2025-08-27)


### Bug Fixes

* Fix autoscrolling to cut elements ([e1d9319](https://github.com/diplodoc-platform/client/commit/e1d9319f87492db12137c2d5a32b581c43e73531))

## [3.10.0](https://github.com/diplodoc-platform/client/compare/v3.9.0...v3.10.0) (2025-08-25)


### Features

* Use hashed assets in client manifest ([b8e0124](https://github.com/diplodoc-platform/client/commit/b8e01246d7dc8fc8d04846ac591280b1e1615e82))


### Bug Fixes

* Fix internal types ([d484f03](https://github.com/diplodoc-platform/client/commit/d484f0354d6f9600653ab6549928df551ce8d173))
* import of search api script file relative to the root ([fb82057](https://github.com/diplodoc-platform/client/commit/fb82057655ff805093525261ad3674b3157e7a96))
* Remove prod deps ([1b84fe3](https://github.com/diplodoc-platform/client/commit/1b84fe39699eaf0def2fe8e61c54676e47f062b8))
* Use postcss instead of lightningcss ([4c3e677](https://github.com/diplodoc-platform/client/commit/4c3e67759b695276529502cd1e19ccacf736daa2))

## [3.9.0](https://github.com/diplodoc-platform/client/compare/v3.8.3...v3.9.0) (2025-08-18)


### Features

* Static search results page ([#187](https://github.com/diplodoc-platform/client/issues/187)) ([db9f506](https://github.com/diplodoc-platform/client/commit/db9f506aeb1742ea126cafae918943c41105076c))


### Bug Fixes

* update version actions, node 22 ([464df4f](https://github.com/diplodoc-platform/client/commit/464df4f842a69e4c5dba52c34e26f257b8eddc40))

## [3.8.3](https://github.com/diplodoc-platform/client/compare/v3.8.2...v3.8.3) (2025-08-04)


### Dependency update

* Update @diplodoc/components to 4.33.0 ([#183](https://github.com/diplodoc-platform/client/issues/183)) ([00adcc0](https://github.com/diplodoc-platform/client/commit/00adcc07db728d95ca795879ef1d7561b64884c1))
* Update @diplodoc/transform to 4.60.0 ([#181](https://github.com/diplodoc-platform/client/issues/181)) ([e5ff304](https://github.com/diplodoc-platform/client/commit/e5ff304c44a053525b38b6778b4f87090199e611))

## [3.8.2](https://github.com/diplodoc-platform/client/compare/v3.8.1...v3.8.2) (2025-07-22)


### Dependency update

* Update @diplodoc/components to 4.31.1 ([#179](https://github.com/diplodoc-platform/client/issues/179)) ([3f68335](https://github.com/diplodoc-platform/client/commit/3f6833521d4546d93d1843bdd3c5cb8b60fd2762))
* Update @diplodoc/transform to 4.59.1 ([#178](https://github.com/diplodoc-platform/client/issues/178)) ([9eb1539](https://github.com/diplodoc-platform/client/commit/9eb1539887a98b4c8b1b342603b8809f4004e52d))

## [3.8.1](https://github.com/diplodoc-platform/client/compare/v3.8.0...v3.8.1) (2025-07-17)


### Bug Fixes

* **mdx:** build ([#177](https://github.com/diplodoc-platform/client/issues/177)) ([ac36636](https://github.com/diplodoc-platform/client/commit/ac3663621f27455bfd673f9954a915180623bc88))


### Dependency update

* Update @diplodoc/client to 3.7.3 ([#175](https://github.com/diplodoc-platform/client/issues/175)) ([e10e656](https://github.com/diplodoc-platform/client/commit/e10e656dc54e1529e3f0d83560b955e591738ffd))

## [3.8.0](https://github.com/diplodoc-platform/client/compare/v3.7.3...v3.8.0) (2025-07-17)


### Features

* added a function for scrolling to the hash ([#174](https://github.com/diplodoc-platform/client/issues/174)) ([96c407e](https://github.com/diplodoc-platform/client/commit/96c407e5d9e7df3af35f56880b03a32e0427a196))
* **mdx:** update mdx extension version ([#172](https://github.com/diplodoc-platform/client/issues/172)) ([b5ef53f](https://github.com/diplodoc-platform/client/commit/b5ef53f9062d905bb5cca93a03ce22f32aab4751))

## [3.7.3](https://github.com/diplodoc-platform/client/compare/v3.7.2...v3.7.3) (2025-07-11)


### Dependency update

* Update @diplodoc/components to 4.30.0 ([#168](https://github.com/diplodoc-platform/client/issues/168)) ([945ab5f](https://github.com/diplodoc-platform/client/commit/945ab5f2b2288c31de735cda26d67fc88a5b0756))

## [3.7.2](https://github.com/diplodoc-platform/client/compare/v3.7.1...v3.7.2) (2025-07-07)


### Bug Fixes

* mv mermaid to devDeps ([4930aa0](https://github.com/diplodoc-platform/client/commit/4930aa02ed52df612b9537969beee63933847b60))

## [3.7.1](https://github.com/diplodoc-platform/client/compare/v3.7.0...v3.7.1) (2025-06-27)


### Dependency update

* Update @diplodoc/page-constructor-extension to 0.9.0 ([#165](https://github.com/diplodoc-platform/client/issues/165)) ([9c5b9d5](https://github.com/diplodoc-platform/client/commit/9c5b9d5114f2519b006c86554dcd27820dcee75d))

## [3.7.0](https://github.com/diplodoc-platform/client/compare/v3.6.3...v3.7.0) (2025-06-25)


### Features

* **render:** Add mdx support ([#164](https://github.com/diplodoc-platform/client/issues/164)) ([7a78bca](https://github.com/diplodoc-platform/client/commit/7a78bcac5cd2e1452e416af8035d7c6d7e521880))


### Bug Fixes

* add prerelease action ([6057683](https://github.com/diplodoc-platform/client/commit/60576836d5dc2a58e13c25ae45b1477689b37bb2))
* update prerelease action ([0eff8da](https://github.com/diplodoc-platform/client/commit/0eff8dac3a453c3d3dd595fb11307d0702d32d30))

## [3.6.3](https://github.com/diplodoc-platform/client/compare/v3.6.2...v3.6.3) (2025-06-06)


### Bug Fixes

* lunr does not have a full results page ([#157](https://github.com/diplodoc-platform/client/issues/157)) ([5a8c7e0](https://github.com/diplodoc-platform/client/commit/5a8c7e07616ee188c90870533f581f6b3e889483))

## [3.6.2](https://github.com/diplodoc-platform/client/compare/v3.6.1...v3.6.2) (2025-06-06)


### Bug Fixes

* provider ssr ([#155](https://github.com/diplodoc-platform/client/issues/155)) ([9a6aed0](https://github.com/diplodoc-platform/client/commit/9a6aed0347333b6c30cc10177387c553a1a7d4b0))

## [3.6.1](https://github.com/diplodoc-platform/client/compare/v3.6.0...v3.6.1) (2025-06-06)


### Bug Fixes

* include RTL CSS files only in their relevant runtime based on filename ([#152](https://github.com/diplodoc-platform/client/issues/152)) ([9dea5d1](https://github.com/diplodoc-platform/client/commit/9dea5d1e829ef01b1d007afb7b6059e4a3dcdc58))

## [3.6.0](https://github.com/diplodoc-platform/client/compare/v3.5.0...v3.6.0) (2025-06-05)


### Features

* add Search page ([#150](https://github.com/diplodoc-platform/client/issues/150)) ([a337e19](https://github.com/diplodoc-platform/client/commit/a337e19c9050a51af0f5ba06d8be75b1228656d8))

## [3.5.0](https://github.com/diplodoc-platform/client/compare/v3.4.6...v3.5.0) (2025-06-03)


### Features

* add algolia provider ([#148](https://github.com/diplodoc-platform/client/issues/148)) ([68ab6b9](https://github.com/diplodoc-platform/client/commit/68ab6b9e1891df4afeeb627c9b97667a47517a0b))

## [3.4.6](https://github.com/diplodoc-platform/client/compare/v3.4.5...v3.4.6) (2025-05-29)


### Dependency update

* Update @diplodoc/page-constructor-extension to 0.5.0 ([#146](https://github.com/diplodoc-platform/client/issues/146)) ([e16e69a](https://github.com/diplodoc-platform/client/commit/e16e69aff6ebcf990486ec71c76838d19e9bd846))

## [3.4.5](https://github.com/diplodoc-platform/client/compare/v3.4.4...v3.4.5) (2025-05-29)


### Dependency update

* Update @diplodoc/page-constructor-extension to 0.4.0 ([#144](https://github.com/diplodoc-platform/client/issues/144)) ([f555ea9](https://github.com/diplodoc-platform/client/commit/f555ea95b755bd7b6ac265a064c3fb8523697998))

## [3.4.4](https://github.com/diplodoc-platform/client/compare/v3.4.3...v3.4.4) (2025-05-29)


### Dependency update

* Update @diplodoc/page-constructor-extension to 0.3.1 ([#142](https://github.com/diplodoc-platform/client/issues/142)) ([2fbf0a1](https://github.com/diplodoc-platform/client/commit/2fbf0a1d353c44c7fe806b91f100ba5d3a995e0e))

## [3.4.3](https://github.com/diplodoc-platform/client/compare/v3.4.2...v3.4.3) (2025-05-27)


### Dependency update

* Update @diplodoc/page-constructor-extension to 0.3.0 ([#140](https://github.com/diplodoc-platform/client/issues/140)) ([bbbc678](https://github.com/diplodoc-platform/client/commit/bbbc6784336dea078ed6cfb9fec2edd69c06120a))

## [3.4.2](https://github.com/diplodoc-platform/client/compare/v3.4.1...v3.4.2) (2025-05-26)


### Bug Fixes

* add search hidden ([27be0cb](https://github.com/diplodoc-platform/client/commit/27be0cbb96aeb681b6d1670bba0d76d4e54b2069))

## [3.4.1](https://github.com/diplodoc-platform/client/compare/v3.4.0...v3.4.1) (2025-05-23)


### Bug Fixes

* use yfm inteface props ([9a7f701](https://github.com/diplodoc-platform/client/commit/9a7f701f827f9473008af97716da14af6fc7ad83))


### Dependency update

* bump components ([aaf1b9d](https://github.com/diplodoc-platform/client/commit/aaf1b9dcee9c401abf64f8923cde1fb71037d30e))

## [3.4.0](https://github.com/diplodoc-platform/client/compare/v3.3.4...v3.4.0) (2025-05-21)


### Features

* add @diplodoc/page-constructor-extension ([#135](https://github.com/diplodoc-platform/client/issues/135)) ([f0de65b](https://github.com/diplodoc-platform/client/commit/f0de65b438a38c4ec692c9e3da093449d799e083))


### Bug Fixes

* comments ([a549d66](https://github.com/diplodoc-platform/client/commit/a549d665670194f473addee47aa6f6a03e647833))
* customize logo type ([3104ef1](https://github.com/diplodoc-platform/client/commit/3104ef124494ebabe3c53cad2467ae45598fe941))

## [3.3.4](https://github.com/diplodoc-platform/client/compare/v3.3.3...v3.3.4) (2025-05-14)


### Bug Fixes

* [#1125](https://github.com/diplodoc-platform/client/issues/1125) no logo in toc ([c7ed82f](https://github.com/diplodoc-platform/client/commit/c7ed82fe5cb7b2b4c70dfe008e9ab01cc1f2b99d))

## [3.3.3](https://github.com/diplodoc-platform/client/compare/v3.3.2...v3.3.3) (2025-04-22)


### Dependency update

* bump @diplodoc/components to 4.26.2 ([#128](https://github.com/diplodoc-platform/client/issues/128)) ([8071c42](https://github.com/diplodoc-platform/client/commit/8071c427d24b4546a7d0f13e8951c0c6e28fef9e))

## [3.3.2](https://github.com/diplodoc-platform/client/compare/v3.3.1...v3.3.2) (2025-04-14)


### Bug Fixes

* Fix locale for UpdatedAt block ([9843010](https://github.com/diplodoc-platform/client/commit/98430105357cbb38b198553c5a10eaca765b748d))

## [3.3.1](https://github.com/diplodoc-platform/client/compare/v3.3.0...v3.3.1) (2025-03-26)


### Dependency update

* Update @diplodoc/transform to 4.51.0 ([#122](https://github.com/diplodoc-platform/client/issues/122)) ([ee43a4e](https://github.com/diplodoc-platform/client/commit/ee43a4e7554325a227378ca4adbcfa6a664e7014))

## [3.3.0](https://github.com/diplodoc-platform/client/compare/v3.2.0...v3.3.0) (2025-03-25)


### Features

* move to tabs runtime ([#113](https://github.com/diplodoc-platform/client/issues/113)) ([109b887](https://github.com/diplodoc-platform/client/commit/109b887c4247a780b71b7c3d71e0cb6d10f0a0e5))
* workflow for deps update ([#120](https://github.com/diplodoc-platform/client/issues/120)) ([ae3383b](https://github.com/diplodoc-platform/client/commit/ae3383b51ddab03e497d5c2657e15d293622323a))


### Bug Fixes

* dev dep ([9581be4](https://github.com/diplodoc-platform/client/commit/9581be4a4f5c4521b78e8b2420dc5cc3e7405540))
* package ([d74a089](https://github.com/diplodoc-platform/client/commit/d74a08974be6e9e691245ab5832e664125db930d))

## [3.2.0](https://github.com/diplodoc-platform/client/compare/v3.1.12...v3.2.0) (2025-03-24)


### Features

* add UserSettingManager ([#114](https://github.com/diplodoc-platform/client/issues/114)) ([7da77aa](https://github.com/diplodoc-platform/client/commit/7da77aa93cc68a998750bf6a75982595d7480853))
* page-constructor scss overrides ([#109](https://github.com/diplodoc-platform/client/issues/109)) ([996e34e](https://github.com/diplodoc-platform/client/commit/996e34e7d4537f7327e35be77d9afce17f918ff7))
* tabs restore on page mount ([#105](https://github.com/diplodoc-platform/client/issues/105)) ([e9afd79](https://github.com/diplodoc-platform/client/commit/e9afd79a7120d0c0400d9a3b0dc795895745b85d))


### Bug Fixes

* disable img compression in PC ([#108](https://github.com/diplodoc-platform/client/issues/108)) ([5e60c5e](https://github.com/diplodoc-platform/client/commit/5e60c5e518f854131c1103c011b76c5153da13ef))
* ismobile prop to page to fix share button ([#106](https://github.com/diplodoc-platform/client/issues/106)) ([64f95d5](https://github.com/diplodoc-platform/client/commit/64f95d59cbd18761ef66f0334a97529899d707dc))
* search query ([#112](https://github.com/diplodoc-platform/client/issues/112)) ([389ffa6](https://github.com/diplodoc-platform/client/commit/389ffa61b9969943e41a084c976e9cd3c5881424))
* subnav not visible [#111](https://github.com/diplodoc-platform/client/issues/111) ([d4efb27](https://github.com/diplodoc-platform/client/commit/d4efb274ac611a45ea8a4363e826d8046b373bb0))
* SUPPORTED_LANGS is an array ([#116](https://github.com/diplodoc-platform/client/issues/116)) ([73be2a7](https://github.com/diplodoc-platform/client/commit/73be2a732a19c3a7dc607c55b3dd240a525235ad))

## [3.1.12](https://github.com/diplodoc-platform/client/compare/v3.1.11...v3.1.12) (2025-02-25)


### Bug Fixes

* use only supported langs ([#103](https://github.com/diplodoc-platform/client/issues/103)) ([5f2353c](https://github.com/diplodoc-platform/client/commit/5f2353ce921472436f2860e7120d0c8733255ab6))

## [3.1.11](https://github.com/diplodoc-platform/client/compare/v3.1.10...v3.1.11) (2025-02-13)


### Bug Fixes

* Fix build for react-hotkeys-hook ([703bf54](https://github.com/diplodoc-platform/client/commit/703bf543868bdb4036f60b593d66ec97f621f8d5))

## [3.1.10](https://github.com/diplodoc-platform/client/compare/v3.1.9...v3.1.10) (2025-02-12)


### Bug Fixes

* add ssr config to PageConstructor ([0bfedba](https://github.com/diplodoc-platform/client/commit/0bfedba85d91449464df7794c914ec3dd983e3f0))
* empty icon fix ([0220768](https://github.com/diplodoc-platform/client/commit/0220768910f9c4bf4d5264655811e80eaa18198a))


### Dependency update

* Update core deps ([5382839](https://github.com/diplodoc-platform/client/commit/53828390314cbf4a9c467c6152bfcb268f648945))

## [3.1.9](https://github.com/diplodoc-platform/client/compare/v3.1.8...v3.1.9) (2024-12-16)


### Bug Fixes

* fixed window top scroll on search input change ([da7d9a6](https://github.com/diplodoc-platform/client/commit/da7d9a60feca161f8565c15df18e33d99aba3c72))

## [3.1.8](https://github.com/diplodoc-platform/client/compare/v3.1.7...v3.1.8) (2024-11-12)


### Bug Fixes

* Extend Lang type by string representation ([447ee7b](https://github.com/diplodoc-platform/client/commit/447ee7b9a4d843f87ad222d528406134c62043f1))
* Fix sass deprecations ([3bd94d3](https://github.com/diplodoc-platform/client/commit/3bd94d355f995a7dd7ca7dc8c5b4b61f486add1d))

## [3.1.7](https://github.com/diplodoc-platform/client/compare/v3.1.6...v3.1.7) (2024-11-12)


### Bug Fixes

* export ConfigData&PreloadParams types ([0456738](https://github.com/diplodoc-platform/client/commit/0456738cf4ff01ed73ec4c23085badbfe0bf62f8))

## [3.1.6](https://github.com/diplodoc-platform/client/compare/v3.1.5...v3.1.6) (2024-11-06)


### Bug Fixes

* Fix page props filtering ([e03f71e](https://github.com/diplodoc-platform/client/commit/e03f71ea00f0c87a9abf74a68f8c4dc7041f2201))

## [3.1.5](https://github.com/diplodoc-platform/client/compare/v3.1.4...v3.1.5) (2024-11-02)


### Bug Fixes

* Fix leading page paddings ([6558a17](https://github.com/diplodoc-platform/client/commit/6558a1775c7a6949e7d161af9ca46344c4e9f5a7))
* Fix page scroll position ([ff5d65f](https://github.com/diplodoc-platform/client/commit/ff5d65fe03ba4a0d701fc1e8b661891c5837f570))

## [3.1.4](https://github.com/diplodoc-platform/client/compare/v3.1.3...v3.1.4) (2024-10-31)


### Bug Fixes

* Fix navigation and layout paddings ([096a325](https://github.com/diplodoc-platform/client/commit/096a3250d6db925f8618f7cfdf93e4aaff02730d))
* Update babel-preset ([3e6db78](https://github.com/diplodoc-platform/client/commit/3e6db785c18e0f10944afe75d5fd51633ca3426d))

## [3.1.3](https://github.com/diplodoc-platform/client/compare/v3.1.2...v3.1.3) (2024-10-19)


### Bug Fixes

* Update packages ([901e74f](https://github.com/diplodoc-platform/client/commit/901e74f1a6f4289cadef99f119dc89ff0ea2a02b))

## [3.1.2](https://github.com/diplodoc-platform/client/compare/v3.1.1...v3.1.2) (2024-10-16)


### Bug Fixes

* Fix pages layout for wide format ([55c668e](https://github.com/diplodoc-platform/client/commit/55c668e9c8908dcb9c03ba12d1fbfa92e6b28e11))
* Fix Search close button for mobile ([49393b4](https://github.com/diplodoc-platform/client/commit/49393b4b6aae1440946eaa1bd285c047572d5a20))
* Fix search input contrast ([4e1d198](https://github.com/diplodoc-platform/client/commit/4e1d198d7cfabc86f6d798b2828f29598ce1c703))

## [3.1.1](https://github.com/diplodoc-platform/client/compare/v3.1.0...v3.1.1) (2024-10-11)


### Bug Fixes

* Fix display controls on pages with navigation ([bda4754](https://github.com/diplodoc-platform/client/commit/bda47547e2b08702980af9527b766fdd1a227b17))
* Fix pages layout for all cases ([c83c201](https://github.com/diplodoc-platform/client/commit/c83c201fd8a41a9cc90f6ed559edda13a5ba548c))
* Fix tabs runtime execution ([cf9937a](https://github.com/diplodoc-platform/client/commit/cf9937ae5dfd3520b633f5b21d8168ac5e6e1e65))
* Replace css `.mobile` class with media rule ([7b804f9](https://github.com/diplodoc-platform/client/commit/7b804f9c30e5410d53daa79c675cc0a4883a1767))

## [3.1.0](https://github.com/diplodoc-platform/client/compare/v3.0.4...v3.1.0) (2024-10-03)


### Features

* Add search for mobile view ([d9ce237](https://github.com/diplodoc-platform/client/commit/d9ce2377e691ccd69f18d53191e4f60679129988))


### Bug Fixes

* Fix landing page mode ([4dcefeb](https://github.com/diplodoc-platform/client/commit/4dcefeb90e1f1fc0b18b1b16bea40dd7a0196837))
* Update sass-loader to remove deprecation warnings ([bd89846](https://github.com/diplodoc-platform/client/commit/bd898464094ce3396948538004e0b4314daa7ce5))

## [3.0.4](https://github.com/diplodoc-platform/client/compare/v3.0.3...v3.0.4) (2024-09-27)


### Bug Fixes

* Add worker loading fallback ([c6d8ef8](https://github.com/diplodoc-platform/client/commit/c6d8ef87726597c9d56054ef78cd5d64caedd21e))

## [3.0.3](https://github.com/diplodoc-platform/client/compare/v3.0.2...v3.0.3) (2024-09-25)


### Bug Fixes

* Add default suggest position if search is enabled ([93a7dea](https://github.com/diplodoc-platform/client/commit/93a7dea7647d6a917a40a7dce186c35361ea1fa7))
* hide OverflowScroller elements ([642e180](https://github.com/diplodoc-platform/client/commit/642e180d8ba2e5a8d6d432a2c485fa0c92093d6b))

## [3.0.2](https://github.com/diplodoc-platform/client/compare/v3.0.1...v3.0.2) (2024-09-24)


### Bug Fixes

* Fix types ([cf642a9](https://github.com/diplodoc-platform/client/commit/cf642a99db6fd5bbc2ddb52509645fb5082a6674))

## [3.0.1](https://github.com/diplodoc-platform/client/compare/v3.0.0...v3.0.1) (2024-09-24)


### Bug Fixes

* Update components ([9a54523](https://github.com/diplodoc-platform/client/commit/9a54523c39abc8b43328603657e6534338de1d03))

## [3.0.0](https://github.com/diplodoc-platform/client/compare/v2.6.2...v3.0.0) (2024-09-24)

### ⚠ BREAKING CHANGES

- Add Search page
- Change manifest.json format

### Features

- Add Search ([5813e0e](https://github.com/diplodoc-platform/client/commit/5813e0ed2adc09d364b978f2cd526178703acdc8))
- Apply root classes as fast as possible ([1f83522](https://github.com/diplodoc-platform/client/commit/1f83522e8d5fcf628051009e1e596b4d21ebdf95))

### Bug Fixes

- Extract PC blocks to isolated modules ([d72cb4a](https://github.com/diplodoc-platform/client/commit/d72cb4a964a10b2f5d1546c81652bd1c27a49522))
- Fix build imports linking mode ([28752fb](https://github.com/diplodoc-platform/client/commit/28752fb0388f0d54f344d282ba0a4c538eadbd56))
- Fix layout defaultProps warning ([a2337ba](https://github.com/diplodoc-platform/client/commit/a2337baae9f9e62c877c48ce4c9f30dd99d196ad))

## [2.8.2](https://github.com/diplodoc-platform/client/compare/v2.8.1...v2.8.2) (2024-09-20)

### Bug Fixes

- update openapi 2.3.2 ([#63](https://github.com/diplodoc-platform/client/issues/63)) ([a774070](https://github.com/diplodoc-platform/client/commit/a7740700805e8dd369df683865f05bab13bbc990))

## [2.8.1](https://github.com/diplodoc-platform/client/compare/v2.8.0...v2.8.1) (2024-09-20)

### Bug Fixes

- Fix build imports linking mode ([e0e4d09](https://github.com/diplodoc-platform/client/commit/e0e4d09b6f47b1174068aa82e7dd36f230af6945))
- update transform & components ([#62](https://github.com/diplodoc-platform/client/issues/62)) ([caf0047](https://github.com/diplodoc-platform/client/commit/caf00477db5106309be270047607a93b0565da27))

## [2.8.0](https://github.com/diplodoc-platform/client/compare/v2.7.0...v2.8.0) (2024-09-17)

### Features

- new mobile-ui and refactoring gravity-ui/page-constructor navigation ([#57](https://github.com/diplodoc-platform/client/issues/57)) ([2d3c90b](https://github.com/diplodoc-platform/client/commit/2d3c90b27d938d394633763700ee6bbeb319078e))

## [2.7.0](https://github.com/diplodoc-platform/client/compare/v2.6.2...v2.7.0) (2024-07-29)

### Features

- add consent popup support ([#55](https://github.com/diplodoc-platform/client/issues/55)) ([7a7a43a](https://github.com/diplodoc-platform/client/commit/7a7a43af5c90da7d36645365bf00d51a8351b67e))

### Bug Fixes

- @diplodoc/components version ([552a407](https://github.com/diplodoc-platform/client/commit/552a4070d292356c91aef6bdd0cdc0159f959411))
- local theme change ([#49](https://github.com/diplodoc-platform/client/issues/49)) ([0b36d30](https://github.com/diplodoc-platform/client/commit/0b36d306b7b25b5757e63371a073b5f2edceb081))
- pop-up definition overlaps header ([#51](https://github.com/diplodoc-platform/client/issues/51)) ([1d5fbf6](https://github.com/diplodoc-platform/client/commit/1d5fbf6d9e4c8689fa627e9851ca1973e4369496))
- SubNavigation appearance ([#54](https://github.com/diplodoc-platform/client/issues/54)) ([9eb5da8](https://github.com/diplodoc-platform/client/commit/9eb5da8f0e15c12ecf1fd3f2149b9be254c77280))
- update @diplodoc/components version ([7196407](https://github.com/diplodoc-platform/client/commit/71964078eff0592c682a58849808ad6b59d682df))

## [2.6.2](https://github.com/diplodoc-platform/client/compare/v2.6.1...v2.6.2) (2024-04-22)

### Bug Fixes

- Fix navigation hosted urls ([2e6a06a](https://github.com/diplodoc-platform/client/commit/2e6a06a3cd181b897652e7f27034df01897bf8e0))
- Remove nav items normalization ([2778728](https://github.com/diplodoc-platform/client/commit/2778728ef5f7cf4767eab4633cc2c2accb1049d0))

## [2.6.1](https://github.com/diplodoc-platform/client/compare/v2.6.0...v2.6.1) (2024-04-15)

### Bug Fixes

- preprocess types ([#45](https://github.com/diplodoc-platform/client/issues/45)) ([6b21901](https://github.com/diplodoc-platform/client/commit/6b2190124915e6723256b32de39a54ff022bbe45))

## [2.6.0](https://github.com/diplodoc-platform/client/compare/v2.5.0...v2.6.0) (2024-04-15)

### Features

- transform yfm in PC ([#43](https://github.com/diplodoc-platform/client/issues/43)) ([ec8f0d4](https://github.com/diplodoc-platform/client/commit/ec8f0d487c35093419b9cc4608621fc5f3b63f6a))

## [2.5.0](https://github.com/diplodoc-platform/client/compare/v2.4.0...v2.5.0) (2024-04-10)

### Features

- configure lang in static client ([#40](https://github.com/diplodoc-platform/client/issues/40)) ([2195b32](https://github.com/diplodoc-platform/client/commit/2195b32d4a36fe330cf222858e56bcf84f185b84))

### Bug Fixes

- pc styles for document mode ([#41](https://github.com/diplodoc-platform/client/issues/41)) ([15540fb](https://github.com/diplodoc-platform/client/commit/15540fbea660093b27f78d1c3d171b316571c7c7))

## [2.4.0](https://github.com/diplodoc-platform/client/compare/v2.3.0...v2.4.0) (2024-04-01)

### Features

- add lang html extention ([#37](https://github.com/diplodoc-platform/client/issues/37)) ([5a0aeac](https://github.com/diplodoc-platform/client/commit/5a0aeacf62c668eb519f5c4b0b41f182c0cdb482))

## [2.3.0](https://github.com/diplodoc-platform/client/compare/v2.2.0...v2.3.0) (2024-04-01)

### Features

- add language control selector for static build ([b918e47](https://github.com/diplodoc-platform/client/commit/b918e474ef02622d417e2617157de64b0d14655d))
- add language control selector for static build ([34e2a6e](https://github.com/diplodoc-platform/client/commit/34e2a6e47711d1b50e0b8ac3299485c543bdd1dc))

### Bug Fixes

- navigation style margin ([#38](https://github.com/diplodoc-platform/client/issues/38)) ([0cd81dc](https://github.com/diplodoc-platform/client/commit/0cd81dcdaa031430a655a5cc8a600e47f34821b1))

## [2.2.0](https://github.com/diplodoc-platform/client/compare/v2.1.1...v2.2.0) (2024-03-26)

### Features

- add page-constructor page ([66cbce1](https://github.com/diplodoc-platform/client/commit/66cbce1790ad47eae62f769859d8476336c7ea6a))

## [2.1.0](https://github.com/diplodoc-platform/client/compare/v2.0.5...v2.1.0) (2024-02-29)

### Features

- build RTL css ([#18](https://github.com/diplodoc-platform/client/issues/18)) ([1992e9e](https://github.com/diplodoc-platform/client/commit/1992e9e29bdbb0302e3ad0eb48d9f4d2132434ca))
- update uikit, components, openapi-extension ([#24](https://github.com/diplodoc-platform/client/issues/24)) ([604a7fd](https://github.com/diplodoc-platform/client/commit/604a7fd4100c6fac332737f139b2099d62ed3c78))

### Bug Fixes

- add ThemeProvider for navigation ([#28](https://github.com/diplodoc-platform/client/issues/28)) ([262fc10](https://github.com/diplodoc-platform/client/commit/262fc10b89798b82ad3d0719c96057e281c762bc))

## [2.0.5](https://github.com/diplodoc-platform/client/compare/v2.0.4...v2.0.5) (2024-02-08)

### Bug Fixes

- Update tabs ([0d4632a](https://github.com/diplodoc-platform/client/commit/0d4632a6e640144971a6c9ec70b1edf355b5fe6f))

## [2.0.4](https://github.com/diplodoc-platform/client/compare/v2.0.3...v2.0.4) (2024-02-07)

### Bug Fixes

- Update transform ([25a4de0](https://github.com/diplodoc-platform/client/commit/25a4de079931c2f240168867cea8c49da1f63da6))

## [2.0.3](https://github.com/diplodoc-platform/client/compare/v2.0.2...v2.0.3) (2024-02-06)

### Bug Fixes

- Notes interaction ([24c8c9e](https://github.com/diplodoc-platform/client/commit/24c8c9e6f3cc76c334047918dea94b1ce973610a))

## [2.0.2](https://github.com/diplodoc-platform/client/compare/v2.0.1...v2.0.2) (2024-02-01)

### Bug Fixes

- add runtime ([0b50b57](https://github.com/diplodoc-platform/client/commit/0b50b5724c59e64f29df3ef8e9eda901577cd01e))

## [2.0.1](https://github.com/diplodoc-platform/client/compare/v2.0.0...v2.0.1) (2023-12-28)

### Bug Fixes

- Update latex-extension ([fb6024f](https://github.com/diplodoc-platform/client/commit/fb6024fedb53bca431f3642c481f00b8a8959b8f))

## [2.0.0](https://github.com/diplodoc-platform/client/compare/v1.2.0...v2.0.0) (2023-12-25)

### ⚠ BREAKING CHANGES

- Add page-construclor layout

### Features

- Add Latex extension ([7d7465f](https://github.com/diplodoc-platform/client/commit/7d7465f2e6737ef7959c14cfbeea1e23c92c9fa7))
- Add page-construclor layout ([59140d6](https://github.com/diplodoc-platform/client/commit/59140d6d3f782ddc9d8d43233529d7085a11b34e))

### Bug Fixes

- Add manifest typings ([d5ec4cc](https://github.com/diplodoc-platform/client/commit/d5ec4cca187c99c3219a181988a9ab7e9ffcf64f))

## [1.2.0](https://github.com/diplodoc-platform/client/compare/v1.1.0...v1.2.0) (2023-12-18)

### Features

- move to diplodoc configs ([7af5282](https://github.com/diplodoc-platform/client/commit/7af5282d2b00abeab22c95d0d2eb6cd16e58ff17))

### Bug Fixes

- bump transformer version ([ebe2490](https://github.com/diplodoc-platform/client/commit/ebe249066dff4fa3020f40dfbbd7b1ad159bbcb7))
- Downgrade markdown-it peer dep ([57e8c31](https://github.com/diplodoc-platform/client/commit/57e8c3151fba4f3c6deba63d4445433015a309b0))
- Export more types ([6a4a84a](https://github.com/diplodoc-platform/client/commit/6a4a84a3be77f4ce0f7aab1cd2b4b4a3d7778beb))
- Get transform version with tabs styles ([e6d5bbc](https://github.com/diplodoc-platform/client/commit/e6d5bbcf87af2f5edd5d8a86c6c686561c2c7134))
- Improove build ([8377377](https://github.com/diplodoc-platform/client/commit/83773774df1aef40e2e04583d8082f20516ae08e))
- **infra:** engines, overrides, bump deps ([a44be1d](https://github.com/diplodoc-platform/client/commit/a44be1d18829354846e002d3d845437c8d71b9f1))
- Optimize build size ([d88189d](https://github.com/diplodoc-platform/client/commit/d88189d7a15535d168193d7070dfa04279ef907f))
- package.json main module ([bc1f2fb](https://github.com/diplodoc-platform/client/commit/bc1f2fb1b5b4d152d4e4c04b67f3d1edb000943f))
- Update @diplodoc/components ([2ad5500](https://github.com/diplodoc-platform/client/commit/2ad5500402d215eda60b4e66d9c37a2faf56be66))
- Update core deps ([16f9a10](https://github.com/diplodoc-platform/client/commit/16f9a1095db9100490d76abe5c2dac644a1c8316))
- Use working doc-tools/transform version ([883c4d2](https://github.com/diplodoc-platform/client/commit/883c4d225fb228c051dbe8455170a6a5cda53ceb))

## [1.1.0](https://github.com/diplodoc-platform/client/compare/v1.0.2...v1.1.0) (2023-12-18)

### Features

- move to diplodoc configs ([7af5282](https://github.com/diplodoc-platform/client/commit/7af5282d2b00abeab22c95d0d2eb6cd16e58ff17))

### Bug Fixes

- bump transformer version ([ebe2490](https://github.com/diplodoc-platform/client/commit/ebe249066dff4fa3020f40dfbbd7b1ad159bbcb7))
- Downgrade markdown-it peer dep ([57e8c31](https://github.com/diplodoc-platform/client/commit/57e8c3151fba4f3c6deba63d4445433015a309b0))
- Export more types ([6a4a84a](https://github.com/diplodoc-platform/client/commit/6a4a84a3be77f4ce0f7aab1cd2b4b4a3d7778beb))
- Get transform version with tabs styles ([e6d5bbc](https://github.com/diplodoc-platform/client/commit/e6d5bbcf87af2f5edd5d8a86c6c686561c2c7134))
- Improove build ([8377377](https://github.com/diplodoc-platform/client/commit/83773774df1aef40e2e04583d8082f20516ae08e))
- **infra:** engines, overrides, bump deps ([a44be1d](https://github.com/diplodoc-platform/client/commit/a44be1d18829354846e002d3d845437c8d71b9f1))
- Optimize build size ([d88189d](https://github.com/diplodoc-platform/client/commit/d88189d7a15535d168193d7070dfa04279ef907f))
- package.json main module ([bc1f2fb](https://github.com/diplodoc-platform/client/commit/bc1f2fb1b5b4d152d4e4c04b67f3d1edb000943f))
- Update @diplodoc/components ([2ad5500](https://github.com/diplodoc-platform/client/commit/2ad5500402d215eda60b4e66d9c37a2faf56be66))
- Update core deps ([16f9a10](https://github.com/diplodoc-platform/client/commit/16f9a1095db9100490d76abe5c2dac644a1c8316))
- Use working doc-tools/transform version ([883c4d2](https://github.com/diplodoc-platform/client/commit/883c4d225fb228c051dbe8455170a6a5cda53ceb))

## [1.0.2](https://github.com/diplodoc-platform/client/compare/v1.0.1...v1.0.2) (2023-12-18)

### Bug Fixes

- **infra:** engines, overrides, bump deps ([a44be1d](https://github.com/diplodoc-platform/client/commit/a44be1d18829354846e002d3d845437c8d71b9f1))
- Update core deps ([16f9a10](https://github.com/diplodoc-platform/client/commit/16f9a1095db9100490d76abe5c2dac644a1c8316))
