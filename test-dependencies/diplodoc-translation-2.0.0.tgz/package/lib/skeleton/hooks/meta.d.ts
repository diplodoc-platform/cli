import type { CustomRenderer, CustomRendererHookParameters } from 'src/renderer';
import type { Consumer } from 'src/consumer';
import type { MarkdownIt } from 'markdown-it';
export declare function metaPlugin(md: MarkdownIt): void;
export declare function meta(this: CustomRenderer<Consumer>, { env }: CustomRendererHookParameters): string;
