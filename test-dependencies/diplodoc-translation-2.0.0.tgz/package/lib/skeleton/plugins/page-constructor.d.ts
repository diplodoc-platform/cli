import type { MarkdownIt } from 'markdown-it';
export declare function pageConstructor(): (md: MarkdownIt) => void;
