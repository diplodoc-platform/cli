import type { MarkdownIt as MdIt } from 'markdown-it';
export default function (md: MdIt): void;
