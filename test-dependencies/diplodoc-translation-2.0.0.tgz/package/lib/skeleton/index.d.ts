import type { ExtractionDiagnostics } from 'src/transform-plugins';
import type { ConsumerOptions } from 'src/consumer';
import type { Hash } from 'src/hash';
export type SkeletonOptions = ConsumerOptions & ExtractionDiagnostics;
/**
 * `warnings` receives problems that left a part of the content untranslated
 * without failing the extraction.
 * @param markdown Original Markdown source.
 * @param options Existing extraction and rendering options.
 * @param hash Placeholder hash generator for the document.
 * @param warnings Receives recoverable extraction warnings.
 * @returns Markdown skeleton with translatable content replaced by placeholders.
 */
export declare function skeleton(markdown: string, options?: SkeletonOptions, hash?: Hash, warnings?: string[]): string;
