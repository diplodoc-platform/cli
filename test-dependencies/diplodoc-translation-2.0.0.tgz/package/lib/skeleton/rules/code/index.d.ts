import type { Renderer } from 'markdown-it';
export declare const code: Renderer['rules'];
