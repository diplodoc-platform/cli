import type { Renderer } from 'markdown-it';
export declare const html: Renderer['rules'];
