import type { Renderer } from 'markdown-it';
export declare const blockquote: Renderer['rules'];
