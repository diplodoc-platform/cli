import type { Renderer } from 'markdown-it';
export declare const text: Renderer['rules'];
