import type { Renderer } from 'markdown-it';
export declare const link: Renderer['rules'];
