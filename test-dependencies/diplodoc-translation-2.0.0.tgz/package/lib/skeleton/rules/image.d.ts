import type { Renderer } from 'markdown-it';
export declare const image: Renderer['rules'];
