import type { Renderer } from 'markdown-it';
export declare const table: Renderer['rules'];
