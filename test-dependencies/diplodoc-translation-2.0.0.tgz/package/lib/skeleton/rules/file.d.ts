import type { Renderer } from 'markdown-it';
export declare const file: Renderer['rules'];
