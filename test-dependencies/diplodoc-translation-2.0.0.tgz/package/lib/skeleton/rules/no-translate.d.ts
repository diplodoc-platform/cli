import type { Renderer } from 'markdown-it';
export declare const noTranslate: Renderer['rules'];
