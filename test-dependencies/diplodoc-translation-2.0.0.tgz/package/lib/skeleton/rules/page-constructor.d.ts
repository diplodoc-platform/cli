import type { Renderer } from 'markdown-it';
export declare const pageConstructor: Renderer['rules'];
