import type { Renderer } from 'markdown-it';
export declare const rules: Renderer['rules'];
