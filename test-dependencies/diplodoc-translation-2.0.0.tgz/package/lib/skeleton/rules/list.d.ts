import type { Renderer } from 'markdown-it';
export declare const list: Renderer['rules'];
