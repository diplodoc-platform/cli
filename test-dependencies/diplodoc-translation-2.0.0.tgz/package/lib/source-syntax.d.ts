import type { MarkdownIt } from 'markdown-it';
/**
 * Source projection of the canonical registered footnote and task-list grammar.
 * @param md - Actual native parser used by the Translation consumer.
 * @returns Nothing; installs source-preserving grammar projections for Translation.
 */
export declare function sourceSyntax(md: MarkdownIt): void;
