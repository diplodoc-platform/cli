import type { Env, MarkdownItOptions, Token } from 'markdown-it';
import MarkdownIt from 'markdown-it';
type Renderer = MarkdownIt.Renderer;
declare const NativeRenderer: typeof import("markdown-it", { with: { "resolution-mode": "import" } }).Renderer;
type Options = Required<MarkdownItOptions>;
export declare enum CustomRendererLifeCycle {
    BeforeRender = 0,
    AfterRender = 1,
    BeforeInlineRender = 2,
    AfterInlineRender = 3
}
export type CustomRendererParams<S = {}> = {
    hooks?: CustomRendererHooks;
    rules?: Renderer['rules'];
    state?: S;
};
export type CustomRendererHooks = Record<string, CustomRendererHook | CustomRendererHook[]>;
export interface CustomRendererHook {
    (parameters: CustomRendererHookParameters): string;
}
export type CustomRendererHookParameters = {
    tokens: Token[];
    options: Options;
    env: Env | undefined;
    map?: [number, number] | null;
    rendered?: string[];
};
type SourceMap = [number, number];
export declare class CustomRenderer<State = {}, Md extends MarkdownIt.MarkdownIt = MarkdownIt.MarkdownIt> extends NativeRenderer {
    readonly state: State;
    readonly md: Md;
    protected hooks: Map<CustomRendererLifeCycle, CustomRendererHook[]>;
    constructor({ hooks, rules, state }: CustomRendererParams<State>, parser: Md);
    setRules(rules: Renderer['rules']): void;
    setHooks(hooks: CustomRendererHooks): void;
    hook(cycle: CustomRendererLifeCycle, hook: CustomRendererHook | CustomRendererHook[]): void;
    render(tokens: Token[], options: Options, env: Env | undefined): string;
    renderInline(tokens: Token[], options: Options, env: Env | undefined, map?: SourceMap | null, inline?: Token): string;
    runHooks(cycle: CustomRendererLifeCycle, parameters: CustomRendererHookParameters): string;
    processToken(tokens: Token[], i: number, options: Options, env: Env | undefined): string;
}
export declare function customRenderer<State = {}, Md extends MarkdownIt.MarkdownIt = MarkdownIt.MarkdownIt>(parser: Md, parameters?: CustomRendererParams<State>): void;
export {};
