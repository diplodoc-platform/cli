import type { Token } from 'markdown-it';
import MarkdownIt from 'markdown-it';
type ProjectionOptions = {
    pipeline: 'skeleton' | 'experiment';
    onTabsContainer?: (token: Token) => void;
};
/**
 * Project canonical colon containers into source tokens for either extraction pipeline.
 * @param md - The actual native parser used by Translation.
 * @param options - Source token convention of the owning pipeline.
 * @returns Nothing; keeps HTML callbacks off the source parser.
 */
export declare function sourceBlockDirectives(md: MarkdownIt.MarkdownIt, options: ProjectionOptions): void;
/**
 * Preserve the source accepted by the existing no-translate inline handler in V2.
 * @param md - Fresh native parser owned by the experimental pipeline.
 * @returns Nothing; preserves the original inline rule registration descriptor.
 */
export declare function sourceNoTranslate(md: MarkdownIt.MarkdownIt): void;
export {};
