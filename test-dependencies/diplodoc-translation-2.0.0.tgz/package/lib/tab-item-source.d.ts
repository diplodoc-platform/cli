import type { Token } from 'markdown-it';
import MarkdownIt from 'markdown-it';
type Options = {
    pipeline: 'skeleton' | 'experiment';
    warnings: string[];
};
/**
 * Create source projection for canonical Tabs item markers on one Translation parser.
 * @param options - Pipeline token convention and recoverable warning receiver.
 * @returns A private accepted-header receiver and the source-only plugin installed last.
 */
export declare function createTabItemSource(options: Options): {
    acceptContainer(token: Token): void;
    plugin: (md: MarkdownIt.MarkdownIt) => void;
};
export {};
