import type { Renderer } from 'markdown-it';
export declare const codeInline: Renderer['rules'];
