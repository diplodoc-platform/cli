import type { Renderer } from 'markdown-it';
export declare function renderLiquid({ subtype, markup, content }: Token): string;
export declare const liquid: Renderer['rules'];
