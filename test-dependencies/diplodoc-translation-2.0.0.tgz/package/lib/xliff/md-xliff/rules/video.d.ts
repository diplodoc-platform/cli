import type { Renderer } from 'markdown-it';
export declare const video: Renderer['rules'];
