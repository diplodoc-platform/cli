import type { Renderer } from 'markdown-it';
export declare const pair: Renderer['rules'];
