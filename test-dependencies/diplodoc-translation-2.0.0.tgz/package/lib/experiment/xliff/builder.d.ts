import type { ReplacePart, TokenExtraMap } from '../types';
import MarkdownIt from 'markdown-it';
import { Xliff } from './xliff';
type Token = MarkdownIt.Token;
export declare const buildXliff: (replaceParts: ReplacePart[], tokenExtraMap: TokenExtraMap, mdData: string, compact?: boolean) => Xliff;
export declare function prepareInlineToken(inlineToken: Token, tokenExtraMap: TokenExtraMap, mdData: string): import("markdown-it", { with: { "resolution-mode": "import" } }).Token[];
export declare function markTokens(tokens: Token[], tokenExtraMap: TokenExtraMap): void;
export {};
