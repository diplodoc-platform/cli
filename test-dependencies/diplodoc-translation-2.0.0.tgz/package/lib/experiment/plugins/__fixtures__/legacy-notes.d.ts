import MarkdownIt from 'markdown-it';
export declare function note(md: MarkdownIt.MarkdownIt): void;
