import MarkdownIt from 'markdown-it';
export declare function cut(md: MarkdownIt.MarkdownIt): void;
