import MarkdownIt from 'markdown-it';
export declare function anchors(md: MarkdownIt.MarkdownIt): void;
