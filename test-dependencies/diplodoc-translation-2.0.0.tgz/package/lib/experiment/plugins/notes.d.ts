import MarkdownIt from 'markdown-it';
/**
 * Install the canonical note grammar and translate its accepted source boundaries.
 * @param md - Translation's native MarkdownIt parser.
 * @returns Nothing; installs the finite source adapter.
 */
export declare function note(md: MarkdownIt.MarkdownIt): void;
