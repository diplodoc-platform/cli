import MarkdownIt from 'markdown-it';
export declare function linksTemplates(md: MarkdownIt.MarkdownIt): void;
