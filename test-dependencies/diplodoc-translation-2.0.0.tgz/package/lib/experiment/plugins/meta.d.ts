import type { MarkdownIt as markdownIt } from 'markdown-it';
export declare function meta(md: markdownIt): void;
