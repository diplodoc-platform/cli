import type countries from '@shellscape/i18n-iso-countries';
import type { Xliff } from 'src/experiment/xliff/xliff';
import type { TransformOptions } from 'src/experiment/transform';
import type { TranslateOptions } from 'src/experiment/translate';
declare const _languagesList: string[];
export type Language = (typeof _languagesList)[number];
export type LanguageLocale = {
    language: Language;
    locale: countries.Alpha2Code;
};
export type TemplateOptions = {
    source: LanguageLocale;
    target: LanguageLocale;
    originalFile: string;
    skeletonFile?: string;
};
interface Experiment {
    useExperimentalParser: true;
}
export type ExtractOptions = Experiment & TemplateOptions & TransformOptions;
export type ExtractOutput = {
    skeleton: string;
    xliff: Xliff;
    /** Problems that left source content untranslated; lines refer to normalized input. */
    warnings?: string[];
};
export type ComposeOptions = Experiment & TranslateOptions;
export interface ComposeOutput {
    document: string;
    variables: Record<string, string>;
    externalFile?: string;
    originalFile: string;
    sourceLanguage: string;
    targetLanguage: string;
}
export {};
