import type { TokenExtraMap } from '../types';
export declare function tokenizeYaml(rawYaml: string, tokenExtraMap: TokenExtraMap, level: number): import("markdown-it", { with: { "resolution-mode": "import" } }).Token;
export declare function yamlVariableReplace(dataArg: string): {
    data: string;
    revert: (dataArgLocal: string) => string;
};
