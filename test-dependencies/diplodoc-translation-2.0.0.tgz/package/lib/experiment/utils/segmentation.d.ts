import type { TokenExtraMap } from '../types';
import MarkdownIt from 'markdown-it';
type Token = MarkdownIt.Token;
export declare function applySegmentation(mdData: string, inlineToken: Token, tokenExtraMap: TokenExtraMap): import("markdown-it", { with: { "resolution-mode": "import" } }).Token[];
export declare function trimInlineToken(mdData: string, inlineToken: Token, tokenExtraMap: TokenExtraMap): import("markdown-it", { with: { "resolution-mode": "import" } }).Token[];
export declare function splitInlineToken(mdData: string, inlineToken: Token, point: number, tokenExtraMap: TokenExtraMap): import("markdown-it", { with: { "resolution-mode": "import" } }).Token[];
export {};
