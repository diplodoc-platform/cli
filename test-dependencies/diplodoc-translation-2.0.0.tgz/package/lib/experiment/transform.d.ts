import type { ExtractionDiagnostics } from 'src/transform-plugins';
export interface TransformOptions extends ExtractionDiagnostics {
    compact?: boolean;
    showTokens?: boolean;
    showMap?: boolean;
    showRawMap?: boolean;
    showVars?: boolean;
}
export declare function transform(content: string, options?: TransformOptions): {
    warnings?: string[] | undefined;
    skeleton: string;
    variables: Map<string, string>;
    xliff: import("./xliff/xliff").Xliff;
};
