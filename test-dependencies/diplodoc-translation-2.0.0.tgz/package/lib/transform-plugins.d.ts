import type { MarkdownIt } from 'markdown-it';
import type { LogConsumer } from '@diplodoc/transform/log';
import { createNotesPlugin } from '@diplodoc/notes-extension/plugin';
export interface ExtractionDiagnostics {
    /** Location of source markup in diagnostics emitted by Transform plugins. */
    originalFile?: string;
    /** Report actual legacy markup through the caller's logger when supplied. */
    log?: LogConsumer;
    deprecationWarnings?: boolean;
}
/**
 * Scope warnings about authored markup to this extraction.
 * @param options - Source name, logger and deprecation policy from the caller.
 * @returns Options for the Transform plugins that recognize legacy markup.
 */
export declare function pluginDiagnostics(options: ExtractionDiagnostics): {
    path: string;
    deprecations: import("@diplodoc/transform/deprecation").DeprecationReporter;
};
/** The complete options forwarded by the existing skeleton pipeline. */
export interface SkeletonPluginOptions {
    notesAutotitle: boolean;
    path: string;
}
type SkeletonPlugin = (md: MarkdownIt, options: SkeletonPluginOptions) => void;
type ExperimentPlugin = (md: MarkdownIt, ...options: [] | [ReturnType<typeof pluginDiagnostics>]) => void;
declare const cut: (<T extends import("@diplodoc/cut-extension").CutToken, C extends import("@diplodoc/cut-extension").CutCoreState<T>, B extends import("@diplodoc/directive").DirectiveBlockState & import("@diplodoc/directive").BlockContentState<B>, I extends import("@diplodoc/directive").DirectiveInlineState>(md: import("@diplodoc/cut-extension").CutHost<T, C, B, I>, { output }?: {
    output?: string | undefined;
}) => void) & {
    collect(input: string, { destRoot }: {
        destRoot: string;
    }): void;
};
/**
 * Native13 boundary for the finite plugins exercised by Translation's runtime tests.
 * Callable validation alone does not establish parser compatibility. Keep this list
 * private to Translation until the plugins publish the native parser-compatible declarations.
 * @returns Skeleton registrations, preserving the parser and original options object.
 */
export declare function skeletonPlugins(): {
    visibility: SkeletonPlugin;
    notes: ReturnType<typeof createNotesPlugin>;
    cut: typeof cut;
    checkbox: SkeletonPlugin;
    monospace: SkeletonPlugin;
    imsize: SkeletonPlugin;
    file: SkeletonPlugin;
    video: SkeletonPlugin;
    table: SkeletonPlugin;
    underline: SkeletonPlugin;
    subscript: SkeletonPlugin;
};
/**
 * Retain the experiment's no-options registrations on its own parser.
 * @returns The finite foreign plugins used by the experiment.
 */
export declare function experimentPlugins(): {
    deflist: ExperimentPlugin;
    imsize: ExperimentPlugin;
    table: ExperimentPlugin;
    underline: ExperimentPlugin;
    subscript: ExperimentPlugin;
};
export {};
