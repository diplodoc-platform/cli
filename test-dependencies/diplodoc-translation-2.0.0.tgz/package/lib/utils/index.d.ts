import MdIt from 'markdown-it';
export declare function token(type: string, props?: Hash): import("markdown-it", { with: { "resolution-mode": "import" } }).Token & Hash<any>;
export declare function stringAttr(token: MdIt.Token, name: string): string | null;
export declare function find(type: string, tokens: Token[], idx: number): Token | null;
export declare function replace(source: string, units: string[], render?: (value: string, offset: number) => string): [string, boolean];
