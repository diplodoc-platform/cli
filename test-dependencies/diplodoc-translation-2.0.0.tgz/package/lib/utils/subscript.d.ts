/**
 * Preserve authored escapes while making a translated body valid for markdown-it-sub 2.0.0.
 * @param body Source-derived subscript body from a translation unit.
 * @returns The body with required delimiter and space escapes.
 */
export declare function escapeSubscriptBody(body: string): string;
